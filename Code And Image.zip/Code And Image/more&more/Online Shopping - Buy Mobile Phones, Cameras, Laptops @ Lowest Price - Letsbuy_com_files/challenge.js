
var RecaptchaState = {
    site : '6LeSRsMSAAAAACqyIIUVDZmNIjv3V_YlkibPtc73',
    challenge : '03AHJ_VutSswn6IscHfN4CR60PzCB8EHf39UfkuB7Au_eNGHwazN4CpRfS9uFNLSOgK9BFj88Mp2FdteGpHD_q-n1QBKPOTR1EO3ey9QRu_glN--mQamii93BpK2EklVY4Qhuv8mJBVwULnkLmH2kTT5HkuoLF4_QiGA',
    is_incorrect : false,
    programming_error : '',
    error_message : '',
    server : 'http://www.google.com/recaptcha/api/',
    timeout : 18000
};

document.write('<scr'+'ipt type="text/javascript" s'+'rc="' + RecaptchaState.server + 'js/recaptcha.js"></scr'+'ipt>');
