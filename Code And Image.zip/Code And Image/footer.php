<script>
function stp()
{
document.getElementById('marq').scrollAmount="0";
}
function ply()
{
document.getElementById('marq').scrollAmount="5";
}
</script>
<body>
<table width="100%">

<tr>
<td class="sml" width="70%" style="border-right:solid 1px #999999; padding:5px; text-align:justify">SouthCityMall is a part of the FutureGroup family.
SouthCityMall is a place to get great deals on your shopping needs.
Try the Daily steals for an exciting new deal every day or Battle it out for great prices in one category every week.
If that's not enough how about browsing the Top 10 to look at our handpicked essentials for themes like travel,
vacation, festivals etc. Shop from the comfort your home and get products at great prices at your doorstep. With easy payment options such as cash on delivery,
Future money EMI, Net Banking and Cheque shopping is more secure and easier than ever. </td>

<td class="mid" valign="top"><img src="images/tele.jpg">&nbsp;CUSTOMER CARE<hr>
<font class="sml"><b>Phone:</b> +91 4758652514<br>
<b>Address:</b> southcitymall.com<br>
10th Floor, Tower C, 247 Park, LBS Marg, Vikhroli (West),<br>
 Mumbai - 400 083.</font> </td>
</tr>



<tr>
<td style="border-top:solid 2px #446499" colspan="2"><marquee onMouseOver="stp()" onMouseOut="ply()" scrollamount="5" id="marq">
<img src="images/addi.jpg" height="75">&nbsp;&nbsp;&nbsp;
<img src="images/bharti-airtel-ltd-logo (1).jpg" height="75">&nbsp;&nbsp;&nbsp;
<img src="images/caste.jpg" height="75">&nbsp;&nbsp;&nbsp;
<img src="images/freetowork.jpg" height="75">&nbsp;&nbsp;&nbsp;
<img src="images/imagesCA79JM1N.jpg" height="75">&nbsp;&nbsp;&nbsp;
<img src="images/intel.jpg" height="75">&nbsp;&nbsp;&nbsp;
<img src="images/bmw-logo.jpg" height="75">&nbsp;&nbsp;&nbsp;
<img src="images/fashion11.gif" height="75">&nbsp;&nbsp;&nbsp;
<img src="images/MphasiS-an-HP-company-logo.png" height="75">&nbsp;&nbsp;&nbsp;
<img src="images/nokia-logo.jpg" height="75">&nbsp;&nbsp;&nbsp;
<img src="images/sony.jpg" height="75">&nbsp;&nbsp;&nbsp;

</marquee></td>
</tr>

<tr>
<td class="blufnt" align="right" style="border-top:double 3px #6B6DC2;" colspan="2">&nbsp;</td>
</tr>

<tr height="35px">
<td background="images/mnu_bg.png" style="color:#FFFFFF; size:16px" colspan="2">&nbsp;</td>
</tr>
</table>
</body>