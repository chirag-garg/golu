<?php
include("page/share.php");
if($_REQUEST[logout]=="logout")
{
  $_SESSION[user]="";
}
?>
<link href="css/sty.css" rel="stylesheet" type="text/css">
<center>
<script src="js/javas.js"></script>
<table width="100%">
<tr><td colspan="2" class="btmbor"><?php include('head.php'); ?></td></tr>
<tr>
<td width="25%"><img src="imgs/shopohlic_26.jpg" /></td>

<td valign="top" style="padding-left:10px">
<!------>
<?php
if($_REQUEST[change]=="" and $_REQUEST[create]=="")
{
?>
<table width="100%">
<tr height="50px"><td class="heading" colspan="2">Login</td></tr>
<form name="login" method="post" action="page/query.php">
<tr height="20px"><td colspan="2">&nbsp;</td></tr>
<tr><td class="nmltxt" width="20%">UserName:</td>
	<td><input type="text" name="username" id="1" value="UserName" style="color:#C0C0C0" onfocus="setdef('1')" onblur="reseting('1')"></td> </tr>
<tr><td class="nmltxt">Password:</td>
	<td><input type="password" name="password" id="2" value="Password" style="color:#C0C0C0" onfocus="setdef('2')" onblur="reseting('2')"></td> </tr>

<tr><td class="nmltxt" width="20%">Login Type:</td>
<td>
<select name="log_type">
<option>Administrator</option>
<option>Staff</option>
<option>Manager</option>
</select>
</td>
</tr>	
<tr><td align="right" colspan="2"><a href="index.php?change=change" class="nmltxt">Change</a></td></tr>
<tr height="20px"><td colspan="2" style="border-bottom:double 3px #4A4EB5" class="redtxt"><?php echo $_REQUEST[msg]; ?>&nbsp;</td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="LogIn" name="login"></td></tr>
</form>
</table>
<?php
}
?>

<!--------------------------------------------------------------------------------------------->

<?php
if($_REQUEST[change]=="change")
{
?>
<table width="100%">
<tr height="50px"><td class="heading" colspan="2">Reseting...</td></tr>
<form name="change" method="post" action="page/query.php">
<tr height="20px"><td colspan="2">&nbsp;</td></tr>
<tr><td class="nmltxt" width="20%">Old UserName:</td>
	<td><input type="text" name="old_username"/></td> </tr>
<tr><td class="nmltxt">Old Password:</td>
	<td><input type="password" name="old_password"></td> </tr>

<tr><td class="nmltxt" width="20%">New UserName:</td>
	<td><input type="text" name="new_username"></td> </tr>
<tr><td class="nmltxt">New Password:</td>
	<td><input type="password" name="new_password"></td> </tr>


<tr height="20px"><td colspan="2" style="border-bottom:double 3px #4A4EB5" class="redtxt"><?php echo $_REQUEST[msg]; ?>&nbsp;</td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="Reset" name="reseting"></td></tr>
</form>
</table>
<?php
}
?>
<!------------------------------------------------------------------------------------>




</td>
</tr>

<tr><td colspan="2"><?php include("foot.php");?></td></tr>

</table>
</center>