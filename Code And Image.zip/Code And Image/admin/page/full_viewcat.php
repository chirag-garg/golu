<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$full_view=mysql_query("select * from category where cat_id='$_REQUEST[cat_view]'");
$fl_data=mysql_fetch_assoc($full_view);
?>
<table width="100%">
<tr height="50px"><td class="heading" colspan="4">Category Details</td></tr>
<tr height="20px"><td colspan="4" align="right"><a href="main.php?select=view_category" class="nmltxt">Back</a></td></tr>
<tr><td class="nmltxt" width='25%'>Category Code:</td>	<td><?php echo $fl_data[cat_id];?></td></tr>
<tr><td class="nmltxt">Name:</td>	<td><?php echo $fl_data[cat_name];?></td></tr>
<tr><td class="nmltxt">Description:</td>	<td><?php echo $fl_data[cat_desc];?></td></tr>

<tr height='20px'><td colspan='4' style='border-bottom:double 3px #4A4EB5'>&nbsp;</td></tr>
</table>