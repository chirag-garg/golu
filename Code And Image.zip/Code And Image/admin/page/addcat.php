<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$v_cat=mysql_query("select * from category"); 
$no_cat=mysql_num_rows($v_cat);
if($_REQUEST[procat])
{
$ret_cat=mysql_query("select * from category where cat_id='$_REQUEST[procat]'");
$updt_cat=mysql_fetch_assoc($ret_cat);
}
$cat_dpt=mysql_query("select * from department");
?>
<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>
<script src="../../js/validation.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="2">Add New Category</td></tr>
<tr height="20px"><td colspan="2" align="right"><a href="main.php?select=view_category" class="nmltxt">
<?php
 if($no_cat>0)
{ print("View Records"); }
else
{ print(" "); }
?>
</a></td></tr>

<form name="addfrm" method="post" action="query.php" onsubmit="return check(this)">
<tr><td class="nmltxt" width="30%">Category Name:</td>
	<td><input type="text" name="procat_name" value="<?php echo $updt_cat[cat_name];?>"/></td>
</tr>

<tr>
<td class="nmltxt">Department:</td>
<td><select name="cat_dept">
<?php
while($c=mysql_fetch_assoc($cat_dpt))
{
$pro_categ=mysql_query("select * from department where dept_id=$updt_cat[cat_dept]");
$procate=mysql_fetch_assoc($pro_categ);
	if($c[dept_name]==$procate[dept_name])
	{
	echo "<option value='$c[dept_id]' selected='selected'>$c[dept_name]</option>"; 
	}
	else
	{
	echo "<option value='$c[dept_id]'>$c[dept_name]</option>";
	}
}
?>
</select></td>
</tr>


<tr><td class="nmltxt" width="30%">Category Despcription:</td>
	<td><textarea name="procat_desc"/></textarea></td>
</tr>
<tr height="40px">
<td align="center" colspan="2">
<?php
if($_REQUEST[procat]=="")
{
echo "<input type='submit' value='Save' name='savebnt_cat'/>";
}
else
{
echo "<input type='submit' value='Update' name='savebnt_cat'/>";
}
?>
</td>
</tr>
<input type="hidden" name="update_cat_id" value="<?php echo $_REQUEST[procat];?>"/>
</form>
</table>