<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$v_stf=mysql_query("select * from staff");
$no_stf=mysql_num_rows($v_stf);
if($_REQUEST[stf])
{
$ret_stf=mysql_query("select * from staff where stf_id='$_REQUEST[stf]'");
$updt_stf=mysql_fetch_assoc($ret_stf);
}
?>
<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>
<script src="../../js/validation.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="2">Add New Staff</td></tr>
<tr height="20px"><td colspan="2" align="right"><a href="main.php?select=view_staff" class="nmltxt">
<?php
 if($no_stf>0)
{ print("View Records"); }
else
{ print(" "); }
?>
</a></td></tr>

<form name="addfrm" method="post" action="query.php" onsubmit="return check(this)">
<tr><td class="nmltxt" width="30%">Staff Name:</td>
	<td><input type="text" name="stf_name" onKeyPress="valid='abcdefghijklmnopqrstuvwxyz '; return limitchar(event)" value="<?php echo $updt_stf[stf_name];?>"/></td>
</tr>


<tr>
<td class="nmltxt">Local Address:</td>
<td><input type="text" name="stf_lc_add" value="<?php echo $updt_stf[stf_lc_add];?>"></td>
</tr>

<tr>
<td class="nmltxt">Permanent Address:</td>
<td><input type="text" name="stf_per_add" value="<?php echo $updt_stf[stf_per_add];?>"></td>
</tr>

<tr>
<td class="nmltxt">Contact:</td>
<td><input type="text" name="stf_cont" maxlength="11" onKeyPress="valid='0123456789-'; return limitchar(event)" value="<?php echo $updt_stf[stf_cont];?>"></td>
</tr>

<tr>
<td class="nmltxt">Salary:</td>
<td><input type="text" name="stf_sal" maxlength="6" onKeyPress="valid='0123456789'; return limitchar(event)" value="<?php echo $updt_stf[stf_sal];?>"></td>
</tr>

<tr height="20px"><td colspan="2" style="border-bottom:double 3px #4A4EB5">&nbsp;</td></tr>

<tr height="40px">
<td align="center" colspan="2">

<?php
if($_REQUEST[stf]=="")
{
echo "<input type='submit' value='Save' name='savebnt_stf'/>";
}
else
{
echo "<input type='submit' value='Update' name='savebnt_stf'/>";
}
?>
</td>
</tr>
<input type="hidden" name="update_stf_id" value="<?php echo $_REQUEST[stf];?>"/>
</form>
</table>