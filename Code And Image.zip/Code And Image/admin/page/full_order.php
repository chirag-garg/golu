<?php
include("share.php");
$e=mysql_query("select * from product_order where ord_id=$_REQUEST[orde]");
$d=mysql_fetch_assoc($e);
$us=mysql_query("select * from users where user_id=$d[ord_usr_id]");
$usr=mysql_fetch_assoc($us);
$p=mysql_query("select * from product where pro_id=$d[ord_pro_id]");
$pr=mysql_fetch_assoc($p);
$dd=date("d/m/Y",$d[ord_date]);
?>
<table width="100%">
<tr height="50px"><td class="heading" colspan="2">Order Details</td></tr>
<tr><td align="right" colspan="2"><a href="main.php?select=order" class="nmltxt">Back</a></td></tr>
<tr><td class="nmltxt" width="30%">Customer:</td>	<td><?php echo $d[ord_usr_name];?></td></tr>
<tr><td class="nmltxt">Customer Address:</td>	<td><?php echo $usr[user_add];?></td></tr>
<tr><td class="nmltxt">Customer City</td>	<td><?php echo $usr[user_city];?></td></tr>
<tr><td class="nmltxt">Customer Mobile:</td>	<td><?php echo $usr[user_mob];?></td></tr>
<tr><td class="nmltxt">Product Name</td>	<td><?php echo $pr[pro_name];?></td></tr>
<tr><td class="nmltxt">Product Amount</td>	<td><?php echo $d[ord_amt];?></td></tr>
<tr><td class="nmltxt">Product Quantity</td>	<td><?php echo $d[ord_pro_qnt];?></td></tr>
<tr><td class="nmltxt">Account No:</td>	<td><?php echo $d[ord_usr_acc];?></td></tr>
<tr><td class="nmltxt">Bank:</td>	<td><?php echo $d[ord_usr_bank];?></td></tr>
<tr><td class="nmltxt">Payment Mode:</td>	<td><?php echo $d[ord_usr_mode];?></td></tr>
<tr><td class="nmltxt">Order Date:</td>	<td><?php echo $dd;?>&nbsp;&nbsp;<font class="sml_desc">(MM/DD/YY)</font></td></tr>
</table>