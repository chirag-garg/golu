<?php
include("share.php");
//if($_SESSION[user]=="")
//{
//header("location:../index.php");
//}
$full_view=mysql_query("select * from department where dept_id='$_REQUEST[dept_view]'");
$fl_data=mysql_fetch_assoc($full_view);
?>
<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="4">Department Details</td></tr>
<tr height="20px"><td colspan="4" align="right"><a href="main.php?select=view_department" class="nmltxt">Back</a></td></tr>
<tr><td class="nmltxt" width='25%'>Name:</td>	<td><?php echo $fl_data[dept_name];?></td></tr>
<tr><td class="nmltxt">Description:</td>	<td><?php echo $fl_data[dept_desc];?></td></tr>
<tr><td class="nmltxt">Contact:</td>	<td><?php echo $fl_data[dept_cont];?></td></tr>
<tr><td class="nmltxt">Department Manager:</td>	<td><?php echo $fl_data[dept_man];?></td></tr>
<tr height="20px"><td colspan="4" style="border-bottom:double 3px #4A4EB5">&nbsp;</td></tr>
</table>