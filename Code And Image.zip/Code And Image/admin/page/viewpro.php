<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$n_txt=nb_text("product","main.php");

if($_REQUEST[st]!="")
{
 $st=$_REQUEST[st];
}
else
{
 $st=0;
}
if($_REQUEST[sel_via]=="category" && $_REQUEST[nme]!="")
{
$ct=mysql_query("select * from category where cat_name='$_REQUEST[nme]'");
$c=mysql_fetch_assoc($ct);
$v_pro=mysql_query("select * from product where pro_cat=$c[cat_id] order by pro_name asc"); 
}
else if($_REQUEST[sel_via]=="department" && $_REQUEST[nme]!="")
{
$dt=mysql_query("select * from department where dept_name='$_REQUEST[nme]'");
$d=mysql_fetch_assoc($dt);
$ct=mysql_query("select * from category where cat_dept=$d[dept_id]");
$c=mysql_fetch_assoc($ct);
$v_pro=mysql_query("select * from product where pro_cat=$c[cat_id] order by pro_name asc "); 
}
else
{
$v_pro=mysql_query("select * from product order by pro_name asc limit $st,5"); 
}
?>

<script>
function sel()
{
val=document.getElementById('sele').value;
//alert(val);
if(val!="all")
document.chosen.nme.style.display="";
else
document.chosen.nme.style.display="none";
}
function subm()
{
document.chosen.submit();
}
</script>


<form action="query.php" name="frm_prod" method="get">
<input type="hidden" name="hiden_prod" value="" />
</form>
<form action="" name="chosen" method="get">
<!--<input type="hidden" name="chose" value="" />-->
<input type="hidden" name="select" value="view_product" />


<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>

<table width="100%">
<tr height="50px"><td class="heading" colspan="4">Product Details</td></tr>
<tr height="20px"><td class="nmltxt" colspan="3">View via:&nbsp;<select onchange="sel();" id="sele" name="sel_via">
						<option value="all_sel">all</option>
						<option value="category">category</option>
						<option value="department">department</option>
					  </select>&nbsp;&nbsp;&nbsp;<input type="text" name="nme" onblur="subm()" size="10" style="display:none"/></td>
</form>
<td colspan="1" align="right"><a href="main.php?select=product" class="nmltxt">Back</a></td></tr>
<tr align="center" class="nmltxt"><td>Name</td>	<td>Category</td> <td>Price</td> <td>Action</td></tr>
<tr><td colspan="4" style="border-top:solid 1px #4A4EB5">&nbsp;</td></tr>
<?php
while($vi=mysql_fetch_assoc($v_pro))
{
$pro_categ=mysql_query("select * from category where cat_id=$vi[pro_cat]");
$procate=mysql_fetch_assoc($pro_categ);
?>
<tr align="center">
<td><?php echo $vi[pro_name];?></td>
<td><?php echo $procate[cat_name];?></td>
<td><?php echo $vi[pro_price];?></td>
<td><a href="main.php?prod=<?php echo $vi[pro_id];?>"class="nmltxt">Edit</a><font color="#4A4EB5">|</font>
<a href="#" onClick="pro_del('<?php echo $vi[pro_id];?>')" class="nmltxt">Delete</a><font color="#4A4EB5">|</font>
<a href="main.php?select=full_view_pro & prod_view=<?php echo $vi[pro_id];?>"class="nmltxt">View</a></td>
</tr>
<?php
}
?>

<tr height="20px"><td colspan="4" style="border-bottom:double 3px #4A4EB5"><?php echo $n_txt;?></td></tr>
</table>