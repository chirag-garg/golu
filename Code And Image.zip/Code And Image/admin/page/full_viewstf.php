<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$full_view=mysql_query("select * from staff where stf_id='$_REQUEST[stf_view]'");
$fl_data=mysql_fetch_assoc($full_view);
?>
<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="4">Staff Details</td></tr>
<tr height="20px"><td colspan="4" align="right"><a href="main.php?select=view_staff" class="nmltxt">Back</a></td></tr>
<tr><td class="nmltxt" width="25%">Name:</td>	<td><?php echo $fl_data[stf_name];?></td></tr>
<tr><td class="nmltxt">Local Address:</td>	<td><?php echo $fl_data[stf_lc_add];?></td></tr>
<tr><td class="nmltxt">Permanent Address:</td>	<td><?php echo $fl_data[stf_per_add];?></td></tr>
<tr><td class="nmltxt">contact:</td>	<td><?php echo $fl_data[stf_cont];?></td></tr>
<tr><td class="nmltxt">Salary:</td>	<td><?php echo $fl_data[stf_sal];?></td></tr>

<tr height="20px"><td colspan="4" style="border-bottom:double 3px #4A4EB5">&nbsp;</td></tr>
</table>