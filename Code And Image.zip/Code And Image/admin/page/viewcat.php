<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$n_txt=nb_text("category","main.php");

if($_REQUEST[st]!="")
{
 $st=$_REQUEST[st];
}
else
{
 $st=0;
}
$v_ct=mysql_query("select * from category order by cat_name asc limit $st,5"); 
?>

<form action="query.php" name="frm_cat" method="get">
<input type="hidden" name="hiden_cat" value="" />
</form>
<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="4">Category Details</td></tr>
<tr height="20px"><td colspan="4" align="right"><a href="main.php?select=category" class="nmltxt">Back</a></td></tr>
<tr align="center" class="nmltxt"><td>Category Code</td>	<td>Category Name</td>   <td>Department</td>   <td>Action</td></tr>
<tr><td colspan="4" style="border-top:solid 1px #4A4EB5">&nbsp;</td></tr>
<?php
while($vi=mysql_fetch_assoc($v_ct))
{
$cat_dept=mysql_query("select * from department where dept_id=$vi[cat_dept]");
$ctdep=mysql_fetch_assoc($cat_dept);
?>
<tr align="center">
<td><?php echo $vi[cat_id];?></td>
<td><?php echo $vi[cat_name];?></td>
<td><?php echo $ctdep[dept_name];?></td>
<td><a href="main.php?procat=<?php echo $vi[cat_id];?>"class="nmltxt">Edit</a><font color="#4A4EB5">|</font>
<a href="#" onclick="cat_del('<?php echo $vi[cat_id];?>')"class="nmltxt">Delete</a><font color="#4A4EB5">|</font>
<a href="main.php?select=full_view_cat&cat_view=<?php echo $vi[cat_id];?>"class="nmltxt">View</a></td>
</tr>
<?php
}
?>

<tr height="20px"><td colspan="4" style="border-bottom:double 3px #4A4EB5"><?php echo $n_txt;?></td></tr>
<tr><td colspan="4" class="redtxt"><?php echo $_REQUEST[msg]; ?>&nbsp;</td></tr>
</table>