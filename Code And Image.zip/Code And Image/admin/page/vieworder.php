<?php
include("share.php");
$n_txt=nb_text("product_order","main.php");

if($_REQUEST[st]!="")
{
 $st=$_REQUEST[st];
}
else
{
 $st=0;
}
$or=mysql_query("select * from product_order order by ord_usr_name asc limit $st,5");

?>
<table width="100%">
<tr height="50px"><td class="heading" colspan="6">Orders</td></tr>
<tr class="nmltxt" align="center"><td>Customer</td><td>Product</td><td>Quantity</td><td>Amount</td><td>Deliver Date</td><td>Action</td></tr>
<tr><td colspan="6" style="border-top:solid 1px #4A4EB5">&nbsp;</td></tr>
	<?php while($rd=mysql_fetch_assoc($or))
	{$opt=mysql_query("select * from product where pro_id=$rd[ord_pro_id]");
	$pt=mysql_fetch_assoc($opt);
	$dd=date("d/m/Y",$rd[ord_date]);
	?>
	<tr align="center"><td><?php echo $rd[ord_usr_name];?></td>
	<td><?php echo $pt[pro_name]; ?></td>
	<td><?php echo $rd[ord_pro_qnt];?></td>
	<td><?php echo $rd[ord_amt];?></td>
	<td><?php echo $dd;?></td>
	<td><a href="main.php?select=full_ord&orde=<?php echo $rd[ord_id];?>" class="nmltxt">Details</a></td></tr>
	<?php
	}
	?>
<tr height="20px"><td colspan="6" style="border-bottom:double 3px #4A4EB5"><?php echo $n_txt;?></td></tr>
</table>
