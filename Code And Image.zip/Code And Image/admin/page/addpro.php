<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$v_prod=mysql_query("select * from product"); 
$no_prod=mysql_num_rows($v_prod);
if($_REQUEST[prod])
{
$ret_prod=mysql_query("select * from product where pro_id='$_REQUEST[prod]'");
$updt_prod=mysql_fetch_assoc($ret_prod);
}
$cat=mysql_query("select * from category");
?>
<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>
<script src="../../js/validation.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="2">Add New Product</td></tr>
<tr height="20px"><td colspan="2" align="right"><a href="main.php?select=view_product" class="nmltxt">
<?php
 if($no_prod>0)
{ print("View Records"); }
else
{ print(" "); }
?>
</a></td></tr>

<form name="addfrm" method="post" action="query.php" enctype="multipart/form-data" onsubmit="return check(this)">
<tr><td class="nmltxt" width="30%">Product Name:</td>
	<td><input type="text" name="pro_name" value="<?php echo $updt_prod[pro_name];?>"/></td>
</tr>

<tr>
<td class="nmltxt">Product Category:</td>
<td><select name="pro_cat">

<?php
while($c=mysql_fetch_assoc($cat))
{
$pro_categ=mysql_query("select * from category where cat_id=$updt_prod[pro_cat]");
$procate=mysql_fetch_assoc($pro_categ);
	if($c[cat_name]==$procate[cat_name])
	{
	echo "<option value='$c[cat_id]' selected='selected'>$c[cat_name]</option>"; 
	}
	else
	{
	echo "<option value='$c[cat_id]'>$c[cat_name]</option>";
	}
}
?>

</select></td>
</tr>

<tr>
<td class="nmltxt">Product Price:</td>
<td><input type="text" name="pro_price" onKeyPress="valid='0123456789'; return limitchar(event)"  value="<?php echo $updt_prod[pro_price]; ?>"></td>
</tr>

<tr>
<td class="nmltxt">Product Min Stock:</td>
<td><input type="text" name="pro_minst" onKeyPress="valid='0123456789'; return limitchar(event)" value="<?php echo $updt_prod[pro_minst];?>" ></td>
</tr>

<tr>
<td class="nmltxt">Product Max Stock:</td>
<td><input type="text" name="pro_maxst" onKeyPress="valid='0123456789'; return limitchar(event)" value="<?php echo $updt_prod[pro_maxst];?>"></td>
</tr>


<tr>
<td class="nmltxt">Description:</td>
<td><input type="text" name="pro_desc" value="<?php echo $updt_prod[pro_desc];?>" ></td>
</tr>


<tr><td class="nmltxt" width="30%">Product Image:</td>
	<td><input type="file" name="pro_img" value=""/></td>
</tr>

<tr height="20px"><td colspan="2" style="border-bottom:double 3px #4A4EB5">&nbsp;</td></tr>

<tr height="40px">
<td align="center" colspan="2">

<?php
if($_REQUEST[prod]=="")
{
echo "<input type='submit' value='Save' name='savebnt_prod'/>";
}
else
{
echo "<input type='submit' value='Update' name='savebnt_prod'/>";
}
?>

</td>
</tr>
<input type="hidden" name="update_prod_id" value="<?php echo $_REQUEST[prod];?>"/>
</form>
</table>
