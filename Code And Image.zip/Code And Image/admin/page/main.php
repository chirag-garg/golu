<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
///////////////////////////////////////////////////////////////////////////////////////////
function nb_text($table,$pg)
{
$sql="Select * from $table";
$rs=mysql_query($sql);
$num=mysql_num_rows($rs);
$n_txt="";
$i=1;
if($num>5)
{
	for($j=0;$j<$num;$j+=5)
	{
	  $n_txt=$n_txt."<a href='$pg?st=$j & select=view_$table' class='lnk'>$i</a>&nbsp;  &nbsp;";
	  $i++;
	}
}
 return $n_txt;
}
///////////////////////////////////////////////////////////////////////////////////////////
$mnth=mysql_query("select * from month");
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if($_REQUEST[item]=="product" && $_REQUEST[srh_name]!="")
{ 
$v_prod=mysql_query("select * from product where pro_name='$_REQUEST[srh_name]'");
$id=mysql_fetch_assoc($v_prod);
header("location:main.php?prod_view=$id[pro_id]"); 
}
else if($_REQUEST[item]=="product" && $_REQUEST[srh_name]=="")
{
header("location:main.php?select=view_product");
} 
/////////////////////////////////////////////
if($_REQUEST[item]=="category" && $_REQUEST[srh_name]!="")
{ 
$v_prod=mysql_query("select * from category where cat_name='$_REQUEST[srh_name]'");
$id=mysql_fetch_assoc($v_prod);
header("location:main.php?cat_view=$id[cat_id]"); 
}
else if($_REQUEST[item]=="category" && $_REQUEST[srh_name]=="")
{
header("location:main.php?select=view_category");
} 
//////////////////////////////////////////////
if($_REQUEST[item]=="staff" && $_REQUEST[srh_name]!="")
{ 
$v_prod=mysql_query("select * from staff where stf_name='$_REQUEST[srh_name]'");
$id=mysql_fetch_assoc($v_prod);
header("location:main.php?stf_view=$id[stf_id]"); 
}
else if($_REQUEST[item]=="staff" && $_REQUEST[srh_name]=="")
{
header("location:main.php?select=view_staff");
} 
//////////////////////////////////////////////
if($_REQUEST[item]=="manager" && $_REQUEST[srh_name]!="")
{ 
$v_prod=mysql_query("select * from manager where man_name='$_REQUEST[srh_name]'");
$id=mysql_fetch_assoc($v_prod);
header("location:main.php?man_view=$id[man_id]"); 
}
else if($_REQUEST[item]=="manager" && $_REQUEST[srh_name]=="")
{
header("location:main.php?select=view_manager");
} 
//////////////////////////////////////////////
if($_REQUEST[item]=="department" && $_REQUEST[srh_name]!="")
{ 
$v_prod=mysql_query("select * from department where dept_name='$_REQUEST[srh_name]'");
$id=mysql_fetch_assoc($v_prod);
header("location:main.php?dept_view=$id[dept_id]"); 
}
else if($_REQUEST[item]=="department" && $_REQUEST[srh_name]=="")
{
header("location:main.php?select=view_department");
} 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
?>
<script>
function prnt()
{
var str="Welcome";
var len=str.length
	i=0;
	document.getElementById('101').innerHTML=charAt(i);
	}
	setTimeout("prnt()",1000)
}
</script>





<link href="../css/sty.css" rel="stylesheet" type="text/css">
<center>
<table width="100%">
<tr><td colspan="2" class="btmbor"><?php include('heading.php'); ?></td></tr>
<tr>
<td width="25%"  bgcolor="#4A4EB5" valign="top" style="border-right:solid 2px #4A4EB5"><?php include('left_menus.php');?></td>

<td valign="top" style="padding-left:10px">

<!-----------------Login----------------------------->
<?php
if($_REQUEST[select]=="login")
{
echo "<body><table width='100%'>
<tr><td>$msg</td></tr>
<tr height='50px'><td class='heading' id='101'>Welcome,</td></tr>
<tr height='20px'><td colspan='2'>&nbsp;</td></tr>
<tr><td class='blufnt'>Welcome to, SOUTH CITY MALL Management System.<br>This system help you to manage all the information related to<br> <b>SOUTH CITY MALL</b>.</td></tr>
</table></body>";
}
?>
<!----------------Login Ends------------------------->


<?php 
if($_REQUEST[select]=="product" or $_REQUEST[prod]!="")
include("addpro.php");
else if($_REQUEST[select]=="view_product")
include("viewpro.php");
else if($_REQUEST[select]=="full_view_pro" or $_REQUEST[prod_view]!="")
include("full_viewpro.php");


if($_REQUEST[select]=="staff" or $_REQUEST[stf]!="")
include("addstf.php");
else if($_REQUEST[select]=="view_staff")
include("viewstf.php");
else if($_REQUEST[select]=="full_view_stf" or $_REQUEST[stf_view]!="")
include("full_viewstf.php");
 

if($_REQUEST[select]=="manager" or $_REQUEST[man]!="")
include("addman.php");
else if($_REQUEST[select]=="view_manager")
include("viewman.php");
else if($_REQUEST[select]=="full_view_man" or $_REQUEST[man_view]!="")
include("full_viewman.php");


if($_REQUEST[select]=="category" or $_REQUEST[procat]!="")
include("addcat.php");
else if($_REQUEST[select]=="view_category")
include("viewcat.php");
else if($_REQUEST[select]=="full_view_cat" or $_REQUEST[cat_view]!="")
include("full_viewcat.php");


if($_REQUEST[select]=="department" or $_REQUEST[dept]!="")
include("adddep.php");
else if($_REQUEST[select]=="view_department")
include("viewdep.php");
else if($_REQUEST[select]=="full_view_dep" or $_REQUEST[dep_view]!="")
include("full_viewdep.php");

if($_REQUEST[select]=="view_product_order")
include('vieworder.php'); 
else if($_REQUEST[select]=="full_ord")
include('full_order.php');
?>
<!-------------------------------------------Close---------------------------------------------->
<!----------------------------------------- Department ----------------------------------------->







<!------------------------------------------Searching------------------------------------------->
<!--------------------------------------------Open---------------------------------------------->
<?php 
if($_REQUEST[select]=="searching")
{
echo "<table width='100%'>
<tr height='50px'><td class='heading' colspan='2'>Search Information</td></tr>
<tr height='20px'><td colspan='2'>&nbsp;</td></tr>
<form name='search_next' action='' method='post'>
<tr><td class='nmltxt' width='30%'>Search About:</td><td><select name='item'>
				<option>product</option>
				<option>staff</option>
				<option>manager</option>
				<option>category</option>
				<option>department</option>
				</select></td></tr>
<tr><td class='nmltxt' width='30%'>Name:</td><td><input type='text' name='srh_name'></td></tr>

<tr height='20px'><td colspan='2' style='border-bottom:double 3px #4A4EB5'>&nbsp;</td></tr>

<tr height='40px'>
<td align='center' colspan='2'><input type='submit' name='search' value='Search'></td></tr>

</form>
</table>";
}
?>
<!-------------------------------------------Close---------------------------------------------->
<?php
if($_REQUEST[create]=="new")
{
?>
<script src="js/javas.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="2">Create New</td></tr>
<form name="new" method="post" action="query.php">
<tr height="20px"><td colspan="2">&nbsp;</td></tr>
<tr><td class="nmltxt" width="20%">UserName:</td>
	<td><input type="text" name="username" id="1"></td> </tr>
<tr><td class="nmltxt">Password:</td>
	<td><input type="password" name="password" id="2"></td> </tr>

<tr><td class="nmltxt" width="20%">Login Type:</td>
<td>
<select name="log_type">
<option>Administrator</option>
<option>Staff</option>
<option>Manager</option>
</select>
</td>
</tr>	

<tr height="20px"><td colspan="2" style="border-bottom:double 3px #4A4EB5" class="redtxt"><?php echo $_REQUEST[msg]; ?>&nbsp;</td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="Create" name="create_bnt"></td></tr>
</form>
</table>
<?php
}
?>

<!-----------------------------------------Searching-------------------------------------------->


</td>
</tr>

<tr><td colspan="2"><?php include("footer.php");?></td></tr>

</table>
</center>

