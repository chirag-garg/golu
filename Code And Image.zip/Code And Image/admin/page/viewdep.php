<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$n_txt=nb_text("department","main.php");

if($_REQUEST[st]!="")
{
 $st=$_REQUEST[st];
}
else
{
 $st=0;
}
$v_dpt=mysql_query("select * from department order by dept_name asc limit $st,5"); 
?>

<form action="query.php" name="frm_dept" method="get">
<input type="hidden" name="hiden_dept" value="" />
</form>
<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="4">Department Details</td></tr>
<tr height="20px"><td colspan="4" align="right"><a href="main.php?select=department" class="nmltxt">Back</a></td></tr>
<tr align="center" class="nmltxt"><td>Name</td>	<td>Contact</td> <td>Manager</td> <td>Action</td></tr>
<tr><td colspan="4" style="border-top:solid 1px #4A4EB5">&nbsp;</td></tr>
<?php
while($vi=mysql_fetch_assoc($v_dpt))
{
$dept=mysql_query("select * from manager where man_id=$vi[dept_man]");
$dept_man=mysql_fetch_assoc($dept);
?>
<tr align="center">
<td><?php echo $vi[dept_name];?></td>
<td><?php echo $vi[dept_cont];?></td>
<td><?php echo $dept_man[man_name];?></td>
<td><a href="main.php?dept=<?php echo $vi[dept_id];?>" class="nmltxt">Edit</a><font color="#4A4EB5">|</font>
<a href="#" onClick="dept_del('<?php echo $vi[dept_id];?>')" class="nmltxt">Delete</a><font color="#4A4EB5">|</font>
<a href="main.php?select=full_view_dep&dept_view=<?php echo $vi[dept_id];?>" class="nmltxt">View</a></td>
</tr>
<?php
}
?>

<tr height="20px"><td colspan="4" style="border-bottom:double 3px #4A4EB5"><?php echo $n_txt;?></td></tr>
</table>