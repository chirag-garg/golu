<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$n_txt=nb_text("staff","main.php");

if($_REQUEST[st]!="")
{
 $st=$_REQUEST[st];
}
else
{
 $st=0;
}
$v_st=mysql_query("select * from staff order by stf_name asc limit $st,5"); 
?>
<form action="query.php" name="frm_stf" method="get">
<input type="hidden" name="hiden_stf" value="" />
</form>
<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="4">Staff Details</td></tr>
<tr height="20px"><td colspan="4" align="right"><a href="main.php?select=staff" class="nmltxt">Back</a></td></tr>
<tr align="center" class="nmltxt"><td>Name</td>	<td>Address</td> <td>Salary</td> <td>Action</td></tr>
<tr><td colspan="4" style="border-top:solid 1px #4A4EB5">&nbsp;</td></tr>
<?php
while($vi=mysql_fetch_assoc($v_st))
{
?>
<tr align="center">
<td><?php echo $vi[stf_name];?></td>
<td><?php echo $vi[stf_per_add];?></td>
<td><?php echo $vi[stf_sal];?></td>
<td><a href="main.php?stf=<?php echo $vi[stf_id];?>" class="nmltxt">Edit</a><font color="#4A4EB5">|</font>
<a href="#" onClick="stf_del('<?php echo $vi[stf_id];?>')"class="nmltxt">Delete</a><font color="#4A4EB5">|</font>
<a href="main.php?select=full_view_stf & stf_view=<?php echo $vi[stf_id];?>"class="nmltxt">View</a></td>
</tr>
<?php
}
?>
<tr height="20px"><td colspan="4" style="border-bottom:double 3px #4A4EB5"><?php echo $n_txt;?></td></tr>
</table>