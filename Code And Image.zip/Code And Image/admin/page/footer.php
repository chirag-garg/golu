<table width="100%">

<tr>
<td class="blufnt" align="right" style="border-top:solid 1px #4A4EB5">&nbsp;</td>
</tr>

<tr height="35px">
<td background="../imgs/mnu_bg.png" style="color:#FFFFFF; size:16px">&nbsp;</td>
</tr>
<tr><td style="border-top:solid 2px #4A4EB5" colspan="2">&nbsp;</td></tr>
</table>