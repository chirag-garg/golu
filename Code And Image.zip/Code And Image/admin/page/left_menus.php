<?php if($_SESSION[user]=="")
{
header("location:../index.php");
}
?>
<script>
function show(id)
{
	if(document.getElementById(id).style.display=="none")
	{
	document.getElementById(id).style.display="";
	}
	else
	{
	document.getElementById(id).style.display="none";
	}
}
</script>


<link href="../css/sty.css" rel="stylesheet" type="text/css">
<table width="100%"  bgcolor="#4A4EB5" height="100%">
<tr>
<td class="mnmnu"><a href="main.php?select=login" class="mnmnu">Home</a></td>
</tr>
<!---faltu--->
<tr><td>
		<table width="100%" style="display:none"><tr><td>&nbsp;</td></tr></table>
</td></tr>
<!--------------->

<tr>
<td class="mnmnu"><a href="#" onClick="show('1')" class="mnmnu">Products</a></td>
</tr>


<tr><td>
		<table width="100%" style="display:none" bgcolor="#FFFFFF" id="1">
		<tr><td><a href="main.php?select=product" class="submnu"><img src="../imgs/bullet.png" class="imgrem">&nbsp;&nbsp;Add New Product</a></td></tr>
		<tr><td><a href="main.php?select=view_product" class="submnu"><img src="../imgs/bullet.png" class="imgrem">&nbsp;&nbsp;View products</a></td></tr>
		</table>
</td></tr>
			


<tr>
<td class="mnmnu"><a href="#" onClick="show('2')" class="mnmnu">Staff</a></td>
</tr>


<tr><td>
		<table width="100%" style="display:none" bgcolor="#FFFFFF" id="2">
		<tr><td><a href="main.php?select=staff" class="submnu"><img src="../imgs/bullet.png" class="imgrem">&nbsp;&nbsp;Add New Staff</a></td></tr>
		<tr><td><a href="main.php?select=view_staff" class="submnu"><img src="../imgs/bullet.png" class="imgrem">&nbsp;&nbsp;View Staff Records</a></td></tr>
		</table>
</td></tr>




<tr>
<td class="mnmnu"><a href="#" onClick="show('3')" class="mnmnu">Manager</a></td>
</tr>


<tr><td>
		<table width="100%" style="display:none" bgcolor="#FFFFFF" id="3">
		<tr><td><a href="main.php?select=manager" class="submnu"><img src="../imgs/bullet.png" class="imgrem">&nbsp;&nbsp;Add New Manager</a></td></tr>
		<tr><td><a href="main.php?select=view_manager" class="submnu"><img src="../imgs/bullet.png" class="imgrem">&nbsp;&nbsp;View Managers Records</a></td></tr>
		</table>
</td></tr>



<tr>
<td class="mnmnu"><a href="#" onClick="show('4')" class="mnmnu">Product Catagory</a></td>
</tr>

<tr><td>
		<table width="100%" style="display:none" bgcolor="#FFFFFF" id="4">
		<tr><td><a href="main.php?select=category" class="submnu"><img src="../imgs/bullet.png" class="imgrem">&nbsp;&nbsp;Add/Update Category</a></td></tr>
		</table>
</td></tr>




<tr>
<td class="mnmnu"><a href="#" onClick="show('5')" class="mnmnu">Department</a></td>
</tr>

<tr><td>
		<table width="100%" style="display:none" bgcolor="#FFFFFF" id="5">
		<tr><td><a href="main.php?select=department" class="submnu"><img src="../imgs/bullet.png" class="imgrem">&nbsp;&nbsp;Add New Department</a></td></tr>
		<tr><td><a href="main.php?select=view_department" class="submnu"><img src="../imgs/bullet.png" class="imgrem">&nbsp;&nbsp;View/Update Department</a></td></tr>
		</table>
</td></tr>

<tr>
<td class="mnmnu"><a href="main.php?select=searching" class="mnmnu">Search Information</a></td>
</tr>

<tr>
<td class="mnmnu"><a href="main.php?select=view_product_order" class="mnmnu">View Orders</a></td>
</tr>

</table>