<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$v_dept=mysql_query("select * from department");
$no_dep=mysql_num_rows($v_dept);
if($_REQUEST[dept])
{
$ret_dept=mysql_query("select * from department where dept_id='$_REQUEST[dept]'");
$updt_dept=mysql_fetch_assoc($ret_dept);
}
$dpt_man=mysql_query("select * from manager");
?>
<table width="100%">
<tr height="50px"><td class="heading" colspan="2">Add New Department</td></tr>
<tr height="20px"><td colspan="2" align="right"><a href="main.php?select=view_department" class="nmltxt">
<?php
 if($no_dep>0)
{ print("View Records"); }
else
{ print(" "); }
?>
</a></td></tr>

<form name="addfrm" method="post" action="query.php" onsubmit="return check(this)">
<tr><td class="nmltxt" width="30%">Department Name:</td>
	<td><input type="text" name="dept_name" value="<?php echo $updt_dept[dept_name];?>"/></td>
</tr>


<tr>
<td class="nmltxt">Description:</td>
<td><input type="text" name="dept_desc" value="<?php echo $updt_dept[dept_desc];?>"></td>
</tr>


<tr>
<td class="nmltxt">Contact:</td>
<td><input type="text" name="dept_cont" maxlength="11" onKeyPress="valid='0123456789-'; return limitchar(event)" value="<?php echo $updt_dept[dept_cont];?>"></td>
</tr>

<tr>
<td class="nmltxt">Manager:</td>
<td><select name="dept_man">
<?php
while($c=mysql_fetch_assoc($dpt_man))
{
$pro_categ=mysql_query("select * from manager where man_id=$updt_dept[dept_man]");
$procate=mysql_fetch_assoc($pro_categ);
	if($c[man_name]==$procate[man_name])
	{
	echo "<option value='$c[man_id]' selected='selected'>$c[man_name]</option>"; 
	}
	else
	{
	echo "<option value='$c[man_id]'>$c[man_name]</option>";
	}
}
?>
</select></td>
</tr>

<tr height="20px"><td colspan="2" style="border-bottom:double 3px #4A4EB5">&nbsp;</td></tr>

<tr height="40px">
<td align="center" colspan="2">
<?php
if($_REQUEST[dept]=="")
{
echo "<input type='submit' value='Save' name='savebnt_dept'/>";
}
else
{
echo "<input type='submit' value='Update' name='savebnt_dept'/>";
}
?>
</td>
</tr>
<input type="hidden" name="update_dept_id" value="<?php echo $_REQUEST[dept];?>"/>
</form>
</table>