<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$full_view=mysql_query("select * from manager where man_id='$_REQUEST[man_view]'");
$fl_data=mysql_fetch_assoc($full_view);
$dt=date('d/m/Y',$fl_data[man_doj]);
?>
<table width="100%">
<tr height="50px"><td class="heading" colspan="4">Manager Details</td></tr>
<tr height="20px"><td colspan="4" align="right"><a href="main.php?select=view_manager" class="nmltxt">Back</a></td></tr>
<tr><td class="nmltxt" width='25%'>Name:</td>	<td><?php echo $fl_data[man_name]; ?></td></tr>
<tr><td class="nmltxt">Local Address:</td>	<td><?php echo $fl_data[man_lc_add];?></td></tr>
<tr><td class="nmltxt">Permanent Address:</td>	<td><?php echo $fl_data[man_per_add];?></td></tr>
<tr><td class="nmltxt">contact:</td>	<td><?php echo $fl_data[man_cont]; ?></td></tr>
<tr><td class="nmltxt">Salary:</td>	<td><?php echo $fl_data[man_sal]; ?></td></tr>
<tr><td class="nmltxt">Date of Joining:</td>	<td><?php echo $dt;?></td></tr>


<tr height="20px"><td colspan="4" style="border-bottom:double 3px #4A4EB5">&nbsp;</td></tr>
</table>