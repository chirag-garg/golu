<?php
include('../page/share.php');
if($_SESSION[user]=="")
{
header("location:../index.php");
}
///////PRODUCT////////////////
if(($_REQUEST[pro_name]!="") && ($_REQUEST[pro_cat]!="") && ($_REQUEST[pro_price]!="") && ($_REQUEST[pro_minst]!="") && ($_REQUEST[pro_maxst]!="") && ($_REQUEST[savebnt_prod]=="Save"))
{
	if($_FILES[pro_img][tmp_name])
	{
	move_uploaded_file($_FILES[pro_img][tmp_name],"../upload/".$_REQUEST[pro_name].".jpg");
	$add="../upload/".$_REQUEST[pro_name].".jpg";
	$user_add="Admin/upload/".$_REQUEST[pro_name].".jpg";
	$adpr="insert into product set
		pro_name='$_REQUEST[pro_name]',
		pro_cat='$_REQUEST[pro_cat]',
		pro_price='$_REQUEST[pro_price]',
		pro_minst='$_REQUEST[pro_minst]',
		pro_maxst='$_REQUEST[pro_maxst]',
		pro_desc='$_REQUEST[pro_desc]',
		pro_img='$add',
		user_pro_img='$user_add'";
	}
	else
	{
	$adpr="insert into product set
		pro_name='$_REQUEST[pro_name]',
		pro_cat='$_REQUEST[pro_cat]',
		pro_price='$_REQUEST[pro_price]',
		pro_minst='$_REQUEST[pro_minst]',
		pro_maxst='$_REQUEST[pro_maxst]',
		pro_desc='$_REQUEST[pro_desc]',
		pro_img='../imgs/blank_images.bmp',
		user_pro_img='images/blank_images.bmp'";
	}
	$ad=mysql_query($adpr) or die(mysql_error());
	$msg="Record Added Successfully";
	header("Location:main.php?select=product");
}

if($_REQUEST[update_prod_id] and $_REQUEST[savebnt_prod]=="Update")
{	
	if($_FILES[pro_img][tmp_name])
	{
	move_uploaded_file($_FILES[pro_img][tmp_name],"../upload/".$_REQUEST[pro_name].".jpg");
	$add="../upload/".$_REQUEST[pro_name].".jpg";
	$user_add="Admin/upload/".$_REQUEST[pro_name].".jpg";
	$ed=mysql_query("update product set
		pro_name='$_REQUEST[pro_name]',
		pro_cat='$_REQUEST[pro_cat]',
		pro_price='$_REQUEST[pro_price]',
		pro_minst='$_REQUEST[pro_minst]',
		pro_maxst='$_REQUEST[pro_maxst]',
		pro_desc='$_REQUEST[pro_desc]',
		pro_img='$add',
		user_pro_img='$user_add'
		where pro_id='$_REQUEST[update_prod_id]'");
	}
	else
	{
	$ed=mysql_query("update product set
		pro_name='$_REQUEST[pro_name]',
		pro_cat='$_REQUEST[pro_cat]',
		pro_price='$_REQUEST[pro_price]',
		pro_minst='$_REQUEST[pro_minst]',
		pro_maxst='$_REQUEST[pro_maxst]',
		pro_desc='$_REQUEST[pro_desc]'
		where pro_id='$_REQUEST[update_prod_id]'");
	}
$msg="Record Updated Successfully";
	header("Location:main.php?select=view_product");
}

if($_REQUEST[hiden_prod])
{
mysql_query("delete from product where pro_id='$_REQUEST[hiden_prod]'");
$msg="Record Delete Successfully";
header("Location:main.php?select=view_product");
}

/////////////////////STAFF//////////////////////////
$doj=mktime(0,0,0,$_REQUEST[stf_doj_month],$_REQUEST[stf_doj_day],$_REQUEST[stf_doj_year]);
if($_REQUEST[stf_name]!="" and $_REQUEST[stf_lc_add]!="" and $_REQUEST[stf_per_add]!="" and $_REQUEST[stf_sal]!="" and $_REQUEST[stf_cont]!="" and $_REQUEST[savebnt_stf]=="Save")
{
	$ins_stf="insert into staff set
		stf_name='$_REQUEST[stf_name]',
		stf_lc_add='$_REQUEST[stf_lc_add]',
		stf_per_add='$_REQUEST[stf_per_add]',
		stf_sal='$_REQUEST[stf_sal]',
		stf_cont='$_REQUEST[stf_cont]',
		stf_doj=$doj";
	$adstf=mysql_query($ins_stf) or die(mysql_error());
$msg="Record Added Successfully";
	header("location:main.php?select=staff");
}

if($_REQUEST[update_stf_id] and $_REQUEST[savebnt_stf]=="Update")
{
$ed=mysql_query("update staff set
		stf_name='$_REQUEST[stf_name]',
		stf_lc_add='$_REQUEST[stf_lc_add]',
		stf_per_add='$_REQUEST[stf_per_add]',
		stf_cont='$_REQUEST[stf_cont]',
		stf_sal='$_REQUEST[stf_sal]'
		where stf_id='$_REQUEST[update_stf_id]'");
$msg="Record Updated Successfully";
	header("location:main.php?select=view_staff");
}

if($_REQUEST[hiden_stf])
{
mysql_query("delete from staff where stf_id='$_REQUEST[hiden_stf]'");
$msg="Record Delete Successfully";
header("location:main.php?select=view_staff");
}
/////////////////////LOGIN///////////////////////////
$sql=mysql_query("select * from admin");
while($dat=mysql_fetch_assoc($sql))
{
	if($_REQUEST[login]=="LogIn")
	{
		if(($_REQUEST[username]==$dat[user_name]) && ($_REQUEST[password]==$dat[user_pass]) && ($_REQUEST[log_type]==$dat[user_type]))
		{
			$_SESSION[user]=$_REQUEST[username];
			header("location:main.php?select=login");
			break;
		}
		else
		{
			$msg="Invalid UserName and Password";
			header("location:../index.php?msg=$msg");
		}
	}
}

if($_REQUEST[reseting])
{
$chg=mysql_query("update admin set user_name='$_REQUEST[new_username]',
				user_pass='$_REQUEST[new_password]' where user_name='$_REQUEST[old_username]'
				 and user_pass='$_REQUEST[old_password]'");
				 $msg="Successfully Reset";
	header("location:../index.php?msg=$msg");
}

if($_REQUEST[create_bnt])
{
mysql_query("insert into admin set
			user_name='$_REQUEST[username]',
			user_pass='$_REQUEST[password]',
			user_type='$_REQUEST[log_type]'");
			$msg="New User Created";
			header("location:main.php?select=login&msg=$msg");
}
//////////////////////////////////////////////

/////////////////////MANAGER//////////////////////////
$doj_man=mktime(0,0,0,$_REQUEST[man_doj_month],$_REQUEST[man_doj_day],$_REQUEST[man_doj_year]);

if($_REQUEST[man_name]!="" and $_REQUEST[man_lc_add]!="" and $_REQUEST[man_per_add]!="" and $_REQUEST[man_sal]!="" and $_REQUEST[man_cont]!=""  and $_REQUEST[savebnt_man]=="Save")
{ 
	$ins_man="insert into manager set
		man_name='$_REQUEST[man_name]',
		man_lc_add='$_REQUEST[man_lc_add]',
		man_per_add='$_REQUEST[man_per_add]',
		man_sal='$_REQUEST[man_sal]',
		man_cont='$_REQUEST[man_cont]',
		man_doj=$doj_man";
	$adman=mysql_query($ins_man) or die(mysql_error());
$msg="Record Added Successfully";
	header("location:main.php?select=manager");
}

if($_REQUEST[update_man_id] and $_REQUEST[savebnt_man]=="Update")
{
$ed=mysql_query("update manager set
		man_name='$_REQUEST[man_name]',
		man_lc_add='$_REQUEST[man_lc_add]',
		man_per_add='$_REQUEST[man_per_add]',
		man_sal='$_REQUEST[man_sal]',
		man_cont='$_REQUEST[man_cont]',
		man_doj=$doj_man
		where man_id='$_REQUEST[update_man_id]'");
$msg="Record Updated Successfully";
	header("Location:main.php?select=view_manager");
}

if($_REQUEST[hiden_man])
{
mysql_query("delete from manager where man_id='$_REQUEST[hiden_man]'");
$msg="Record Delete Successfully";
header("Location:main.php?select=view_manager");
}
////////////////////////Product Category/////////////////////////////////////
if(($_REQUEST[procat_name]!="") && ($_REQUEST[procat_desc]!="") && ($_REQUEST[savebnt_cat]=="Save"))
{
$ins_cat=mysql_query("insert into category set
						cat_name='$_REQUEST[procat_name]',
						cat_desc='$_REQUEST[procat_desc]',
						cat_dept='$_REQUEST[cat_dept]'");
$msg="Record Added Successfully";
header("location:main.php?select=category");
}


if($_REQUEST[hiden_cat])
{
mysql_query("delete from category where cat_id='$_REQUEST[hiden_cat]'");
$msg="Record Delete Successfully";
header("Location:main.php?select=view_category");
}


if($_REQUEST[update_cat_id] and $_REQUEST[savebnt_cat]=="Update")
{
$upt_cat=mysql_query("update category set 
					cat_name='$_REQUEST[procat_name]',
					cat_desc='$_REQUEST[procat_desc]',
					cat_dept='$_REQUEST[cat_dept]'
					where cat_id='$_REQUEST[update_cat_id]'");
$msg="Record Updated Successfully";
	header("Location:main.php?select=view_category");
}

////////////////////////Department////////////////////////////////
if($_REQUEST[dept_name]!="" and $_REQUEST[dept_desc]!="" and $_REQUEST[dept_man]!="" and $_REQUEST[dept_cont]!="" and $_REQUEST[savebnt_dept]=="Save")
{
	$ins_dept="insert into department set
		dept_name='$_REQUEST[dept_name]',
		dept_desc='$_REQUEST[dept_desc]',
		dept_cont='$_REQUEST[dept_cont]',
		dept_man='$_REQUEST[dept_man]'";
	$addept=mysql_query($ins_dept) or die(mysql_error());
$msg="Record Added Successfully";
	header("location:main.php?select=department");
}

if($_REQUEST[update_dept_id] and $_REQUEST[savebnt_dept]=="Update")
{
$ed=mysql_query("update department set
		dept_name='$_REQUEST[dept_name]',
		dept_desc='$_REQUEST[dept_desc]',
		dept_cont='$_REQUEST[dept_cont]',
		dept_man='$_REQUEST[dept_man]'
		where dept_id='$_REQUEST[update_dept_id]'");
$msg="Record Updated Successfully";
	header("location:main.php?select=view_department");
}

if($_REQUEST[hiden_dept])
{
mysql_query("delete from department where dept_id='$_REQUEST[hiden_dept]'");
$msg="Record Delete Successfully";
header("location:main.php?select=view_department");
}
///////////////////////////////////////////////////////////////////////////////////////////
?>