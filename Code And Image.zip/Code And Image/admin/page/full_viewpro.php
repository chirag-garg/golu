<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$full_view=mysql_query("select * from product where pro_id='$_REQUEST[prod_view]'");
$fl_data=mysql_fetch_assoc($full_view);
?>
<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="4">Product Details</td></tr>
<tr height="20px"><td colspan="4" align="right"><a href="main.php?select=view_product" class="nmltxt">Back</a></td></tr>
<tr><td class="nmltxt" width="25%">Name:</td>	<td width="30%"><?php echo $fl_data[pro_name];?></td> <td rowspan="5" valign="top"><img src="<?php echo $fl_data[pro_img];?>" height="140px" /></td></tr>
<tr><td class="nmltxt">Category:</td>	<td><?php echo $fl_data[pro_cat];?></td></tr>
<tr><td class="nmltxt">Price:</td>	<td><?php echo $fl_data[pro_price];?> </td></tr>
<tr><td class="nmltxt">Min Stock:</td>	<td><?php echo $fl_data[pro_minst];?></td></tr>
<tr><td class="nmltxt">Max Stock:</td>	<td><?php echo $fl_data[pro_maxst];?></td></tr>

<tr height="20px"><td colspan="4" style="border-bottom:double 3px #4A4EB5">&nbsp;</td></tr>
</table>