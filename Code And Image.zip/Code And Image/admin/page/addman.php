<?php
include("share.php");
if($_SESSION[user]=="")
{
header("location:../index.php");
}
$v_man=mysql_query("select * from manager");
$no_man=mysql_num_rows($v_man);
if($_REQUEST[man])
{
$ret_man=mysql_query("select * from manager where man_id='$_REQUEST[man]'");
$updt_man=mysql_fetch_assoc($ret_man);
}
$dpt=mysql_query("select * from department");
?>
<link href="../css/sty.css" rel="stylesheet" type="text/css">
<script src="../js/javas.js"></script>
<script src="../../js/validation.js"></script>
<table width="100%">
<tr height="50px"><td class="heading" colspan="2">Add New Manager</td></tr>
<tr height="20px"><td colspan="2" align="right"><a href="main.php?select=view_manager" class="nmltxt">
<?php 
 if($no_man>0)
{ print("View Records"); }
else
{ print(" "); }
?>
</a></td></tr>

<form name="addfrm" method="post" action="query.php" onsubmit="return check(this)">
<tr><td class="nmltxt" width="30%">Manager Name:</td>
	<td><input type="text" name="man_name" value="<?php echo $updt_man[man_name];?>"/></td>
</tr>


<tr>
<td class="nmltxt">Local Address:</td>
<td><input type="text" name="man_lc_add" value="<?php echo $updt_man[man_lc_add];?>"></td>
</tr>

<tr>
<td class="nmltxt">Permanent Address:</td>
<td><input type="text" name="man_per_add" value="<?php echo $updt_man[man_per_add];?>"></td>
</tr>

<tr>
<td class="nmltxt">Contact:</td>
<td><input type="text" name="man_cont" maxlength="11" onKeyPress="valid='0123456789-'; return limitchar(event)" value="<?php echo $updt_man[man_cont];?>"></td>
</tr>

<tr>
<td class="nmltxt">Salary:</td>
<td><input type="text" onKeyPress="valid='0123456789'; return limitchar(event)" maxlength="6" name="man_sal" value="<?php echo $updt_man[man_sal];?>"></td>
</tr>

<tr><td class="nmltxt" width="30%">Date of Joining:</td>
	<td><select name="man_doj_day">
<option>Day:</option>
<?php
for($i=1;$i<=31;$i++)
{
$dd=date('d',$updt_man[man_doj]);
		if($dd==$i)
		$sel="selected=selected";
		echo "<option value='$i' $sel'>$i</option>";
		$sel="";
}
?>
</select>

<select name="man_doj_month">
<option>Month:</option>
<?php
while($dt=mysql_fetch_assoc($mnth))
{
$dd=date('M',$updt_man[man_doj]);
		if($dd==$dt[mnth_name])
		{
		 echo "<option value='$dt[mnth_id]' selected='selected'>$dt[mnth_name]</option>";
		}
		else
		{
		echo "<option value='$dt[mnth_id]'>$dt[mnth_name]</option>";
		}
}
?>
</select>

<select name="man_doj_year">
<option>Year:</option>
<?php
$c_year=(date('Y',time())-20);

for($i=$c_year-15;$i<=$c_year;$i++)
{
$dd=date('Y',$updt_man[man_doj]);
		if($dd==$i)
		{
		  echo "<option value='$i' selected='selected'>$i</option>";
		}
		else
		{
		  echo "<option value='$i'>$i</option>";
		}
}
?>
</select>
</td>
</tr>

<tr height="20px"><td colspan="2" style="border-bottom:double 3px #4A4EB5">&nbsp;</td></tr>

<tr height="40px">
<td align="center" colspan="2">
<?php
if($_REQUEST[man]=="")
{
echo "<input type='submit' value='Save' name='savebnt_man'/>";
}
else
{
echo "<input type='submit' value='Update' name='savebnt_man'/>";
}
?>
</td>
</tr>
<input type="hidden" name="update_man_id" value="<?php echo $_REQUEST[man];?>"/>
</form>
</table>