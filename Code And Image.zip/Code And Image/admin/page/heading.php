<link href="../css/sty.css" rel="stylesheet" type="text/css">
<center>
<table width="100%">
<tr>
<td colspan="2"><img src="../imgs/imagesCABCSYTD.jpg"></td>
</tr>

<tr>
<td class="redtxt" colspan="2">
<?php $d = date("D".', '."d".' '."M".' '."Y");
print $d; ?></td>
</tr>

<tr height="35px">
<td background="../imgs/mnu_bg.png" style="color:#FFFFFF; size:16px" colspan="2"><marquee><font color="#FFFFFF" size="+1">"SOUTH CITY MALL"</font> everything for everyone.</marquee></td>
</tr>

<tr>
<td style="border-bottom:solid 1px #4A4EB5"><a href="main.php?create=new" class="nmltxt">Create New</a></td><td class="blufnt" align="right" style="border-bottom:solid 1px #4A4EB5">ADMINISTRATOR LOGIN!&nbsp;&nbsp;<a href="../index.php?logout=logout" class="blufnt">Logout</a></td>
</tr>
<tr height="20px"><td colspan="2">&nbsp;</td></tr>
</table>
</center>