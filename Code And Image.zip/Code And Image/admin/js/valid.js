function cat_del(id)
{
  if(confirm("Are You Sure To Delete"))
  {
     document.frm_cat.hiden_cat.value=id;
	 document.frm_cat.submit();
  }
}
function pro_del(id)
{
  if(confirm("Are You Sure To Delete"))
  {
     document.frm_prod.hiden_prod.value=id;
	 document.frm_prod.submit();
  }
}

function stf_del(id)
{
  if(confirm("Are You Sure To Delete"))
  {
     document.frm_stf.hiden_stf.value=id;
	 document.frm_stf.submit();
  }
}

function man_del(id)
{
  if(confirm("Are You Sure To Delete"))
  {
     document.frm_man.hiden_man.value=id;
	 document.frm_man.submit();
  }
}

function dept_del(id)
{
  if(confirm("Are You Sure To Delete"))
  {
     document.frm_dept.hiden_dept.value=id;
	 document.frm_dept.submit();
  }
}

