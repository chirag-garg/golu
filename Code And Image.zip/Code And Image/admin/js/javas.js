function cat_del(id)
{
  if(confirm("Are You Sure To Delete"))
  {
     document.frm_cat.hiden_cat.value=id;
	 document.frm_cat.submit();
  }
}
function pro_del(id)
{
  if(confirm("Are You Sure To Delete"))
  {
     document.frm_prod.hiden_prod.value=id;
	 document.frm_prod.submit();
  }
}

function stf_del(id)
{
  if(confirm("Are You Sure To Delete"))
  {
     document.frm_stf.hiden_stf.value=id;
	 document.frm_stf.submit();
  }
}

function man_del(id)
{
  if(confirm("Are You Sure To Delete"))
  {
     document.frm_man.hiden_man.value=id;
	 document.frm_man.submit();
  }
}

function dept_del(id)
{
  if(confirm("Are You Sure To Delete"))
  {
     document.frm_dept.hiden_dept.value=id;
	 document.frm_dept.submit();
  }
}





//////////////////////////
////Function for numeric and character checking////
valid="0123456789."; // onKeypress="goods='abcd'; return limitchar(event)"
function limitchar(e)
{
	var key, keychar;
	if (window.event)
		key=window.event.keyCode;
	else if (e)
		key=e.which;
	else
		return true;
	keychar = String.fromCharCode(key);
	keychar = keychar.toLowerCase();
	valid = valid.toLowerCase();
	if (valid.indexOf(keychar) != -1)
	{
		valid="0123456789.";
		return true;
	}
	if ( key==null || key==0 || key==8 || key==9 || key==13 || key==27 )
	{
		valid="0123456789.";
		return true;
	}
	return false;
}
////////////////////////////////////

function setdef(id)
{
	if(document.getElementById(id).value=="UserName")
	{
		document.getElementById(id).value="";
		document.getElementById(id).style.color="";
	}
	else if(document.getElementById(id).value=="Password")
	{
		document.getElementById(id).value="";
		document.getElementById(id).style.color="";
	}
}

function reseting()
{
	if(document.login.username.value=="")
	{
		document.login.username.value="UserName";
		document.login.username.style.color="#C0C0C0";
	}
	else if(document.login.password.value=="")
	{
		document.login.password.value="Password";
		document.login.password.style.color="#C0C0C0";
	}
}
