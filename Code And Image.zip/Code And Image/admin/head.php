<link href="css/sty.css" rel="stylesheet" type="text/css">
<center>
<table width="100%">
<tr>
<td><img src="imgs/imagesCABCSYTD.jpg"></td>
</tr>

<tr>
<td class="redtxt">
<?php $d = date("D".', '."d".' '."M".' '."Y");
print $d; ?></td>
</tr>

<tr height="35px">
<td background="imgs/mnu_bg.png" style="color:#FFFFFF; size:16px"><marquee><font color="#FFFFFF" size="+1">"SOUTH CITY MALL"</font> everything for everyone.</marquee></td>
</tr>

<tr>
<td>&nbsp;</td>
</tr>
<tr height="20px"><td>&nbsp;</td></tr>
</table>
</center>