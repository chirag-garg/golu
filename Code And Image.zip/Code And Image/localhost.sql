-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 17, 2011 at 04:14 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shopping`
--
CREATE DATABASE `shopping` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `shopping`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_name` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `user_name`, `user_pass`, `user_type`) VALUES
(1, 'Max', 'mac', 'Administrator'),
(2, 'Shubham', 'honey', 'Administrator'),
(3, 'Pradeep', 'p', 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL auto_increment,
  `cart_pro_id` int(11) NOT NULL,
  `cart_usr_id` int(11) NOT NULL,
  `cart_pro_qnt` int(11) NOT NULL,
  PRIMARY KEY  (`cart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `cart_pro_id`, `cart_usr_id`, `cart_pro_qnt`) VALUES
(14, 14, 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL auto_increment,
  `cat_name` varchar(255) NOT NULL,
  `cat_desc` varchar(255) NOT NULL,
  `cat_dept` varchar(255) NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_desc`, `cat_dept`) VALUES
(1, 'PC Games', 'pc games', '1'),
(2, 'CD Games', '', '1'),
(3, 'DVD Games', 'dvd games', '1'),
(19, 'Mens Apparels', 'Mens apparels', '8'),
(5, 'Refrigerator', '', '1'),
(6, 'Nokia', 'nokia', '3'),
(7, 'Samsung', 'samsung', '3'),
(8, 'Pen', 'pen', '4'),
(9, 'Pencils', 'pencils', '4'),
(10, 'Mens Deodrant', 'Mens Deodrant', '5'),
(11, 'Womens Deodrant', 'Womens Deodrant', '5'),
(12, 'Bollywood', 'Bollywood', '6'),
(13, 'Hollywood', 'hollywood', '6'),
(14, 'English Literature', 'English Literature', '7'),
(15, 'Poetry', 'poetry', '7'),
(16, 'Autobiographies', 'Autobiographies', '7'),
(17, 'Bussiness Management', 'Bussiness Management', '7'),
(18, 'Art & Image', 'Art & Image', '7'),
(20, 'Ladies Apparels', 'Ladies Apparels', '8'),
(21, 'Bangles/Bracelets', 'Bangles', '8'),
(22, 'Televisions', 'Televisions', '2'),
(23, 'Camera', 'Camera', '2'),
(24, 'Toys', 'Toys', '1');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dept_id` int(11) NOT NULL auto_increment,
  `dept_name` varchar(255) NOT NULL,
  `dept_add` varchar(255) NOT NULL,
  `dept_city` varchar(255) NOT NULL,
  `dept_cont` varchar(11) NOT NULL,
  `dept_man` int(11) NOT NULL,
  `dept_desc` varchar(255) NOT NULL,
  PRIMARY KEY  (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_id`, `dept_name`, `dept_add`, `dept_city`, `dept_cont`, `dept_man`, `dept_desc`) VALUES
(1, 'Fun & Games', '', '', '7845122345', 1, 'fun'),
(2, 'Electronics', '', '', '4521456512', 2, 'elct'),
(3, 'Mobiles', '', '', '2222-415266', 3, 'mob'),
(4, 'Stationary', '', '', '4512-456578', 1, 'stationary'),
(5, 'Beauty Products', '', '', '2222-451236', 2, 'beauty'),
(6, 'Movies & Films', '', '', '45123654', 3, 'movies'),
(7, 'Books', '', '', '8777874565', 2, 'books'),
(8, 'Apparels', '', '', '8565231245', 2, 'apparels');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `man_id` int(11) NOT NULL auto_increment,
  `man_name` varchar(255) NOT NULL,
  `man_lc_add` varchar(255) NOT NULL,
  `man_per_add` varchar(255) NOT NULL,
  `man_sal` int(11) NOT NULL,
  `man_cont` int(11) NOT NULL,
  `man_doj` int(11) NOT NULL,
  PRIMARY KEY  (`man_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`man_id`, `man_name`, `man_lc_add`, `man_per_add`, `man_sal`, `man_cont`, `man_doj`) VALUES
(1, 'Solanki Kesarwani', 'Allahabad', 'Allahabad', 15000, 2147483647, 631477800),
(2, 'Shubham', 'Allahabad', 'Allahabad', 15000, 2147483647, 663013800),
(3, 'Nitish Srivastava', 'Delhi', 'Allahabad', 18000, 2147483647, 599682600);

-- --------------------------------------------------------

--
-- Table structure for table `month`
--

CREATE TABLE `month` (
  `mnth_id` int(11) NOT NULL auto_increment,
  `mnth_name` varchar(255) NOT NULL,
  PRIMARY KEY  (`mnth_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `month`
--

INSERT INTO `month` (`mnth_id`, `mnth_name`) VALUES
(1, 'Jan'),
(2, 'Feb'),
(3, 'Mar'),
(4, 'Apr'),
(5, 'May'),
(6, 'Jun'),
(7, 'Jul'),
(8, 'Aug'),
(9, 'Sep'),
(10, 'Oct'),
(11, 'Nov'),
(12, 'Dec');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pro_id` int(11) NOT NULL auto_increment,
  `pro_name` varchar(255) NOT NULL,
  `pro_price` int(11) NOT NULL,
  `pro_cat` varchar(255) NOT NULL,
  `pro_minst` int(11) NOT NULL,
  `pro_maxst` int(11) NOT NULL,
  `pro_img` varchar(255) NOT NULL,
  `user_pro_img` varchar(255) NOT NULL,
  `pro_desc` varchar(255) NOT NULL,
  PRIMARY KEY  (`pro_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pro_id`, `pro_name`, `pro_price`, `pro_cat`, `pro_minst`, `pro_maxst`, `pro_img`, `user_pro_img`, `pro_desc`) VALUES
(1, 'Piers Plowman', 200, '14', 5, 20, '../upload/Piers Plowman.jpg', 'Admin/upload/Piers Plowman.jpg', 'Piers Plow'),
(2, 'Nine Lives', 175, '14', 4, 5, '../upload/Nine Lives.jpg', 'Admin/upload/Nine Lives.jpg', 'By: Hagotten Stevenberg'),
(3, 'To Kill a MockingBird', 255, '14', 5, 5, '../upload/To Kill a MockingBird.jpg', 'Admin/upload/To Kill a MockingBird.jpg', 'By: Harper Lee'),
(4, 'Nokia-N8', 20995, '6', 0, 5, '../upload/Nokia-N8.jpg', 'Admin/upload/Nokia-N8.jpg', '12mp camera/10inch screen/bluetooth'),
(5, 'The Coral Island', 229, '14', 7, 5, '../upload/The Coral Island.jpg', 'Admin/upload/The Coral Island.jpg', 'based on the true story'),
(6, 'Samsung Galaxy-2', 29295, '7', 3, 5, '../upload/Samsung Galaxy-2.jpg', 'Admin/upload/Samsung Galaxy-2.jpg', '10"wide screen/ width 12mm/ windows supported'),
(7, 'Nokia-5230 Music Xpress', 7875, '6', 12, 10, '../upload/Nokia-5230 Music Xpress.jpg', 'Admin/upload/Nokia-5230 Music Xpress.jpg', '4GB exp/ 100mb internal/ bluetooth'),
(8, 'Bombay-Kurtas', 595, '20', 5, 6, '../upload/Bombay-Kurtas.jpg', 'Admin/upload/Bombay-Kurtas.jpg', 'Bombay Soft Products'),
(9, 'The Smoothy T-Shirts', 725, '19', 5, 12, '../upload/The Smoothy T-Shirts.jpg', 'Admin/upload/The Smoothy T-Shirts.jpg', 'Products of: Funkys'),
(10, 'Color-Bangles', 112, '21', 15, 5, '../upload/Color-Bangles.jpg', 'Admin/upload/Color-Bangles.jpg', 'The product of Madras-Bangles'),
(11, 'Sony Bravia-II', 37285, '22', 10, 5, '../upload/Sony Bravia-II.jpg', 'Admin/upload/Sony Bravia-II.jpg', '32"wide screen/20mm+videocon DTH free'),
(12, 'Kodak-shotX512', 9779, '23', 11, 6, '../upload/Kodak-shotX512.jpg', 'Admin/upload/Kodak-shotX512.jpg', '12mp/5"screen/256mb internal/2GB expandable'),
(13, 'Remote control dirt bike', 575, '24', 10, 5, '../upload/Remote control dirt bike.jpg', 'Admin/upload/Remote control dirt bike.jpg', 'with 4 pencils cells/ smooth shokker wheels'),
(14, 'Samsung Hero-2k', 2795, '7', 10, 5, '../upload/Samsung Hero-2k.jpg', 'Admin/upload/Samsung Hero-2k.jpg', '3G/ 2GB expandable/ Bluetooth'),
(15, 'Nokia C2', 4959, '6', 10, 12, '../upload/Nokia C2.jpg', 'Admin/upload/Nokia C2.jpg', 'Dual sim/ 4GB/ touch & type'),
(16, '300', 175, '13', 9, 10, '../upload/300.jpg', 'Admin/upload/300.jpg', 'The Warriors of Titans'),
(17, 'Twilight', 225, '13', 8, 10, '../upload/Twilight.jpg', 'Admin/upload/Twilight.jpg', 'Horror+Romantic'),
(18, 'Avatar', 300, '13', 14, 15, '../upload/Avatar.jpg', 'Admin/upload/Avatar.jpg', 'Action movie in 3D');

-- --------------------------------------------------------

--
-- Table structure for table `product_order`
--

CREATE TABLE `product_order` (
  `ord_id` int(11) NOT NULL auto_increment,
  `ord_usr_name` varchar(255) NOT NULL,
  `ord_usr_id` int(11) NOT NULL,
  `ord_pro_id` int(11) NOT NULL,
  `ord_pro_qnt` varchar(255) NOT NULL,
  `ord_usr_acc` varchar(255) NOT NULL,
  `ord_usr_bank` varchar(255) NOT NULL,
  `ord_usr_mode` varchar(255) NOT NULL,
  `ord_date` int(11) NOT NULL,
  `ord_vat` int(11) NOT NULL,
  `ord_amt` int(11) NOT NULL,
  PRIMARY KEY  (`ord_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `product_order`
--

INSERT INTO `product_order` (`ord_id`, `ord_usr_name`, `ord_usr_id`, `ord_pro_id`, `ord_pro_qnt`, `ord_usr_acc`, `ord_usr_bank`, `ord_usr_mode`, `ord_date`, `ord_vat`, `ord_amt`) VALUES
(1, 'a', 4, 16, '1', '3', 'Bank of Baroda', 'Account', 1331366400, 7, 182),
(2, '', 6, 14, '1', '', '', '', 0, 0, 0),
(3, '', 6, 14, '1', '', '', '', 0, 0, 0),
(4, '', 6, 14, '1', '', '', '', 0, 0, 0),
(5, '', 6, 14, '1', '', '', '', 0, 0, 0),
(6, 'Shubham', 6, 9, '5', '748596555', 'Bank of Baroda', 'Credit Card', 1336633200, 145, 3770),
(7, '', 6, 14, '1', '', '', '', 0, 0, 0),
(8, '', 6, 14, '1', '', '', '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `stf_id` int(11) NOT NULL auto_increment,
  `stf_name` varchar(255) NOT NULL,
  `stf_lc_add` varchar(255) NOT NULL,
  `stf_per_add` varchar(255) NOT NULL,
  `stf_sal` int(11) NOT NULL,
  `stf_cont` int(11) NOT NULL,
  `stf_doj` int(11) NOT NULL,
  PRIMARY KEY  (`stf_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`stf_id`, `stf_name`, `stf_lc_add`, `stf_per_add`, `stf_sal`, `stf_cont`, `stf_doj`) VALUES
(5, 'Ankit', 'Dehradun', 'Allahabad', 12000, 2147483647, 943900200),
(4, 'Mausham', 'allahabad', 'allahabad', 35000, 2147483647, 943900200),
(7, 'Anuj', 'delhi', 'Delhi', 12500, 532, 943900200),
(8, 'Sonam', 'Allahabad', 'Allahabad', 12000, 232, 943900200),
(9, 'shubh', 'Jabalpur', 'Jabalpur', 12500, 2147483647, 943900200);

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `test_id` int(11) NOT NULL auto_increment,
  `test_name` varchar(255) NOT NULL,
  `test_email` varchar(255) NOT NULL,
  `test_desc` varchar(1000) NOT NULL,
  PRIMARY KEY  (`test_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`test_id`, `test_name`, `test_email`, `test_desc`) VALUES
(1, 'Honey', 'hani@gmail.com', 'Hi ! my name is Shubham Jaiswal.'),
(2, 'Ram Kapoor', 'ram@gmail.com', 'Hi SCM Team, I and my friend both have received the freebies for the Toshiba laptop. Thanks a lot for providing the resolution. It was a pleasant shopping experience shopping with you. My first laptop, which i was looking to buy since long, you provided me at the best price. I am very much happy & satisfied with my purchase. When it come to online shopping, Letsbuy is my first preference. You guys Rock:-). Love shopping with you.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_fname` varchar(255) NOT NULL,
  `user_lname` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `user_add` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_city` varchar(255) NOT NULL,
  `user_mob` varchar(11) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_fname`, `user_lname`, `user_pass`, `user_add`, `user_email`, `user_city`, `user_mob`) VALUES
(6, 'Honey', 'Jaiswal', 'honey', 'Allahabad', 'hani@gmail.com', 'Allahabad', '8808874812'),
(5, 'www', 'ww', 'rtrt', 'ww', 'acs.aa@gmail.com', 'ww', '34554566576'),
(4, 'Mausham', 'Sharma', 'max', 'allahabad', 'max@gmail.com', 'allahabad', '8808874802'),
(7, 'Ram', 'Kapoor', 'ram', 'Mumbai', 'ram@gmail.com', 'Mumbai', '8956213221');
