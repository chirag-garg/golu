<?php 
include("share.php");
$tp_mnu=mysql_query("select * from department");
if($_REQUEST[id])
{
$selected_mnu=mysql_query("select * from department where dept_id=$_REQUEST[id]");
$sub_mnu=mysql_query("select * from category where cat_dept=$_REQUEST[id]");
}
?>
<script>
function dip(ide)
{
document.menu.submit();
document.menu.hid.value=ide;
}
function hide(id)
{
document.getElementById(id).style.display="none";
}
function disp(id)
{
document.getElementById(id).style.display="";
}
</script>

<link href="css/style.css" rel="stylesheet" type="text/css" />
<center>

<div class="div<?php echo $_REQUEST[id]; ?>" id="202" onmouseover="disp('202')" onmouseout="hide('202')">
<table>
<?php if($_REQUEST[id]!="")
{
while($sb_mn=mysql_fetch_assoc($sub_mnu))
{
?>
<tr><td class="sbmnu"><a href="index.php?cat_id=<?php echo $sb_mn[cat_id];?>"><?php echo $sb_mn[cat_name]; ?></a></td></tr>
<?php  } }?>
</table>
</div>



<div class="div<?php echo $_REQUEST[left]; ?>" id="201" onmouseover="disp('201')" onmouseout="hide('201')">
<table>
<?php if($_REQUEST[left]!="")
{
$lft_mnu=mysql_query("select * from department");
while($lft_mn=mysql_fetch_assoc($lft_mnu))
{
?>
<tr><td class="sbmnu"><a href="index.php?lft_dept=<?php echo $lft_mn[dept_id]; ?>"><?php echo $lft_mn[dept_name]; ?></a></td></tr>
<?php  } }?>
</table>
</div>



<table width="100%" border="0">
<tr>
<td style="padding-left:15px"><img src="images/imagesCABCSYTD.jpg"></td>

<td class="blu_sml" align="right">
<a href="http://www.twitter.com"><img src="images/Free-Twitter-Bird-Icon-Sets-17.jpg"  border="none" /></a>&nbsp;
<a href="http://www.gmail.com"><img src="images/gmail_4.png"  border="none" /></a>&nbsp;
<a href="http://www.facebook.com"><img src="images/facebook-icon.png"  border="none" /></a>&nbsp;
</td>
</tr>
<form name="menu" action="">
<input type="hidden" name="hid" id="1" value="" />
</form>
<tr height="35px">
<td background="images/mnu_bg.png" colspan="2" style="color:#FFFFFF; size:16px" class="tpmnu"><a href="index.php" onclick="refresh();">&nbsp;Home</a>&nbsp;<a href="index.php?left=left"><img src="images/smallDownArrow.gif" border="none" /></a>&nbsp;|&nbsp;
<?php
while($tp_mn=mysql_fetch_assoc($tp_mnu))
{
?>

<a href="index.php?id=<?php echo $tp_mn[dept_id]; ?>" title="<?php echo $tp_mn[dept_name]; ?>"><?php echo $tp_mn[dept_name]; ?></a>&nbsp;|&nbsp;

<?php
}
?>
</td>
</tr>

</table>
</center>

