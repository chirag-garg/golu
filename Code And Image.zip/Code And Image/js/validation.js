// JavaScript Document
///////////////////only strings///////////////////
function onlyString(evt)
{
	var e = event || evt; 
	var charCode = e.which || e.keyCode;
	if ((charCode < 65 || charCode > 122) && (charCode!=32)|| (charCode>90 &&charCode<97) )
	{
	  	return false;
	}
	return true;
}
//////////////////////////////Only Number///////////////////////
function onlyNumbers(evt)
{
	var e = event || evt; 
	var charCode = e.which || e.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;

	return true;

}
////////////////////////////////////////////////////////////
function isInteger(s)
{
      var i;
	  s1 = s.value;
      for (i = 0; i < s1.length; i++)
      {
        var c = s1.charAt(i);
        if (isNaN(c)) 
	    {
		alert("Given value is not a number");
		s.value="";
		s.focus();
		return false;
		}
      }
      return true;
} 


function isNumberKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	return false;
	
	
	return true;
}

/////////////////////////blank/////////////////////////////
function Blank(s)
{
if(s.value=="")
{
  alert("Blank not Allow");
  alert("Blank not Allow");
}
}

///////////////////////////////////////////////////////
function check (f)
{
	var done = true, e, i = 0
	while (e = f.elements[i++])
	{
		if ((e.type == 'text' && e.value=="")||(e.type == 'textarea' && e.value=="")||(e.type == 'select' && e.value=="") ||(e.type == 'radio' && e.value==""))
	 {
		e.style.background = '#E6E6E6';
		e.onfocus = function ()
		{
			this.style.background = '#FFFFFF';
		}
		done = false
	 }
	}
	if (!done)
	{
	 alert ('Please, one or more required fields are missing.');
	 return done;
	}
}
///////////////////////////////////////////////
///////////////////E-mail Checking/////////////

function checkEmail(s) 
{
//var email = document.getElementById('emailaddress');
var email = s;
var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!filter.test(email.value))
	{
	alert('Please provide a valid email address');
	s.value="";
	s.focus();
	return false;
	}
}
////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////


//////////////////////////
////Function for numeric and character checking////
valid="0123456789."; // onKeypress="goods='abcd'; return limitchar(event)"
function limitchar(e)
{
	var key, keychar;
	if (window.event)
		key=window.event.keyCode;
	else if (e)
		key=e.which;
	else
		return true;
	keychar = String.fromCharCode(key);
	keychar = keychar.toLowerCase();
	valid = valid.toLowerCase();
	if (valid.indexOf(keychar) != -1)
	{
		valid="0123456789.";
		return true;
	}
	if ( key==null || key==0 || key==8 || key==9 || key==13 || key==27 )
	{
		valid="0123456789.";
		return true;
	}
	return false;
}
////////////////////////////////////
