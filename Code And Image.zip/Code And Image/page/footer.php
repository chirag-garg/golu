<script>
var j=0;
function mov()
{
	var photo=new Array("images/2-980x300.jpg","images/1-980x300.jpg","images/ipad_980x300.jpg");
	document.getElementById('111').src=photo[j];
	document.getElementById('11').scrollamount=0;
	var len=photo.length;
	j++;
	
	if(j>=len)
	{
	j=0;
	}
	setTimeout("goo()",5000);
}
function goo()
{
document.getElementById('11').scrollamount=25;
setTimeout("mov",500);
}
</script>
<body>
<table width="100%">

<!--<tr><td><marquee id="11" scrollamount="" scrolldelay="1"><img id="111" src="" height="150" width="490" /></marquee></td></tr>-->

<tr>
<td class="blufnt" align="right" style="border-top:double 3px #6B6DC2;">&nbsp;</td>
</tr>

<tr height="35px">
<td background="images/mnu_bg.png" style="color:#FFFFFF; size:16px">&nbsp;</td>
</tr>
</table>
</body>