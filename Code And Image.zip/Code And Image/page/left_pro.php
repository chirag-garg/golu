<?php 
include("share.php");
$lft_pro=mysql_query("select * from product where pro_minst>0 order by rand() limit 0,5");
?>
<table width="100%">
<?php
while($lft=mysql_fetch_assoc($lft_pro))
{
?>
<tr><td rowspan="2" width="80px"><img src="<?php echo $lft[user_pro_img];?>" height="70px"/></td>	<td class="normal" width="70px" valign="bottom" width="90px"><a href="index.php?prod_id=<?php echo $lft[pro_id];?>"><?php echo $lft[pro_name];?></a></td></tr>
<tr><td class="sml" valign="top"><?php echo $lft[pro_desc];?></td></tr>
<?php
}
?>
</table>