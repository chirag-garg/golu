<?php 
include("share.php");
if($_REQUEST[fst_name]!="")
{
$qry="insert into users set
				user_fname='$_REQUEST[fst_name]',
				user_lname='$_REQUEST[lst_name]',
				user_pass='$_REQUEST[pass]',
				user_add='$_REQUEST[addr]',
				user_email='$_REQUEST[email]',
				user_city='$_REQUEST[city]',
				user_mob='$_REQUEST[mob]'";
		mysql_query($qry);
header("location:../index.php?login=log");
}
else
{
header("location:../index.php?login=log");
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$sql=mysql_query("select * from users");
while($dat=mysql_fetch_assoc($sql))
{
	if($_REQUEST[usr_name]!="" && $_REQUEST[usr_pass]!="")
	{
		if(($_REQUEST[usr_name]==$dat[user_fname]) && ($_REQUEST[usr_pass]==$dat[user_pass]))
		{	
			$_SESSION[user_main]=$dat[user_fname];
			header("location:../index.php?wel=wel&usr=$_REQUEST[usr_name]");
			break;
		}
		else
		{
			$msg="Invalid UserName and Password";
			header("location:../index.php?login=log&msg=$msg");
		}
	}
}
//////////////////////////////////////////////////////////////////////////////////////

?>
