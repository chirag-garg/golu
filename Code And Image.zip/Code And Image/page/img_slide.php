<script>
var i=0;
function slide()
{	
	
	$("#101").fadeToggle();
	var img=new Array("images/Diya-mirza_bannermain.jpg","images/todays-deal-29sep_banner.jpg","images/battle-bags-290911_bannermain.jpg","images/bags3-980x300.jpg","images/980X300.jpg","images/nikon-summer-cashbacks_980x300-b.jpg");
	document.getElementById('101').src=img[i];
	$("#101").fadeToggle();
	var len=img.length;
	i++;
	
	if(i>=len)
	{
	i=0;
	} 
	setTimeout("slide()",5000);
}
</script>

<body onLoad="slide()">
<table width="100%" cellpadding="0px" cellspacing="0px">
<tr><td class="imact()" align="center" style="border-bottom:solid 2px #4A4EB5; border-top:solid 2px #4A4EB5;"><a href="#"><img src="" width="900px" id="101" style="border:solid #C0C0C0 1px;" height="200px" /></a></td></tr>
</table>
</body>