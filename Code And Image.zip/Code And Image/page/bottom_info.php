<?php include("share.php");
$btm=mysql_query("select * from product order by rand() limit 0,20");
$ct_btm=mysql_query("select * from category order by rand() limit 0,20");
$feed=mysql_query("select * from testimonial order by rand() limit 0,1");
$f=mysql_fetch_assoc($feed);
?>
<body>
<table border="0">
<tr><td bgcolor="#E1E1E1" class="sbmnu" style="padding:5px; border:solid 1px #C0C0C0" colspan="5"><font class="mid"><b>Popular Products:</b></font>&nbsp;
<?php while($bt=mysql_fetch_assoc($btm))
{srand((double) microtime()*10000000);
 $colr=array("#308DA9","#AA1FFF","#551FAA","#6A7C49","#2A5F55","#9B2493","#3C9391");
 $ran=array_rand($colr,1);
 $sz=array("12px","15px","13px","14px","16px");
 $ransz=array_rand($sz,1);
 ?>
<a href="index.php?prod_id=<?php echo $bt[pro_id];?>" id="ran_pro"><?php echo $bt[pro_name];?></a>&nbsp;&nbsp;
<?php
}
?>
</td></tr>


<tr><td colspan="5" style="border-top:solid 1px #C0C0C0">
<table border="0" width="100%" cellspacing="0px" bgcolor="">
<tr><td class="mid" width="35%" style="border-right:solid 1px #C0C0C0">CUSTOMER TESTIMONIALS</td> <td class="mid" width="35%" align="center" style="border-right:solid 1px #C0C0C0">HOW DO YOU LIKE OUR WEBSITE?</td> <td class="mid" width="30%" style="padding-left:30px">PAYMENT MODES</td></tr>
<tr><td class="sml" style="border-right:solid 1px #C0C0C0; text-align:justify; padding:5px" valign="top"><img src="images/testimonials_icon2.jpg" /><?php echo $f[test_desc];?><br /><font style="text-align:right" class="norm"><?php echo $f[test_name];?></font></td> 
<td class="sml" align="center" valign="top" style="border-right:solid 1px #C0C0C0"><b onClick="dis()" style="cursor:pointer">We'd like to get your feedback</b><br><img src="images/feedback-icon.png"></td> 
<td class="sml" valign="top" style="padding-left:30px">Cash on Delivery(COD)<br />Net Banking<br />
								Credit Card<br />Cheque/Demand Draft<br />
								Debit Card</td>

</tr>
</table>
</td></tr>



<tr height="35px"><td colspan="5" class="mid" style="border:1px solid #C0C0C0; padding-left:10px" background="images/Untitled.png">SouthCityMall-Categories</td></tr>




		
		<tr>
		<?php
		global $i;
		$i=0;	
		while($ctbt=mysql_fetch_assoc($ct_btm))
		{
		?>
		<td class="sbmnu">
		<a href="index.php?cat_id=<?php echo $ctbt[cat_id];?>"><?php echo $ctbt[cat_name];?></a>
		</td>	
		<?php
		$i++;
		if($i%5==0)
		{
		?>
		</tr>
		<?php
		}
		}
		?>

<tr height="35px"><td colspan="5" style="border:1px solid #C0C0C0;" background="images/Untitled.png">&nbsp;</td></tr>

</table>
</body>




