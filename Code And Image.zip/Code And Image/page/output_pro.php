<?php 
include("share.php");
$pro=mysql_query("select * from product where pro_cat='$_REQUEST[cat_id]' and pro_minst>0");
$p=mysql_num_rows($pro);
$cat=mysql_query("select * from category where cat_id='$_REQUEST[cat_id]'");
$ct_nm=mysql_fetch_assoc($cat);
?>
<script>
function bnt()
{
document.getElementById('bbnt').src="images/regis_hover.bmp";
}
function bnt_chg()
{
document.getElementById('bbnt').src="images/regis.bmp";
}
function shoow()
{
$("#fl_img").show({height:100},"slow");
}
function hidee()
{
$("#fl_img").hide({height:100},"slow");
}
function tmc()
{
$("#terms").slideDown();
}
function clen()
{
$("#terms").slideUp();
}
function dis()
{
$("#dd").show({height:100},"slow");
}
function hde()
{
$("#dd").hide({height:100},"slow");
document.feed_frm.fname.value="";
document.feed_frm.femail.value="";
document.feed_frm.fdesc.value="";
}
function submt()
{
document.log_frm.submit();
}

function chk()
{
$a=parseInt(document.getElementById('stk').innerHTML);
$b=parseInt(document.getElementById('qnt').value);
if($b<=$a)
{ }
else {alert("Too much quantity");
document.getElementById('qnt').value="1";}

if($b>1)
{document.cart_frm.cart_qnt.value=$b;}
else 
{document.cart_frm.cart_qnt.value=1;}
}

function qnt(qnt)
{ 
document.purchase_frm.tot_qnt.value=qnt;
alert(document.purchase_frm.tot_qnt.value);
document.qnt_frm.submit();
 }

function buy_submt()
{ document.bill_frm.bnme.value=document.getElementById('n').innerHTML;
 	 document.bill_frm.bqnt.value=document.getElementById('8').innerHTML;
	  document.bill_frm.bacc.value=document.getElementById('9').innerHTML;
	  document.bill_frm.bbank.value=document.getElementById('10').innerHTML;
	  document.bill_frm.bpmode.value=document.getElementById('11').innerHTML;
	  document.bill_frm.bvat.value=document.getElementById('13').innerHTML;
	  document.bill_frm.bamt.value=document.getElementById('14').innerHTML;
}
</script>
<?php
if($_REQUEST[cat_id] and $p>0 and $_REQUEST[prod_id]=="")
{
?>
		<table border="0" cellpadding="5px" width="100%">
		<tr><td class="head" style="border-bottom:double 4px #446499" colspan="4"><?php echo $ct_nm[cat_name];?></td></tr>
		<tr>
		<?php
		global $i;
		$i=0;	
		while($prod=mysql_fetch_assoc($pro))
		{
		?>
		<td>
		<table style="border:solid 1px #CCCCCC; padding:5px" width="200px" border="0">
		<tr><td rowspan="2" width="75px"><img src="<?php echo $prod[user_pro_img];?>" height="100px" width="85px" border="none"/></td>	<td style="border-bottom:solid 1px #446499" valign="bottom" class="normal" width="85px"><a href="index.php?prod_id=<?php echo $prod[pro_id];?>&cat_id=<?php echo $_REQUEST[cat_id];?>"><?php echo $prod[pro_name];?></a></td></tr>
		<tr><td valign="top" class="sml"><?php echo $prod[pro_desc];?></td></tr>
		</table>
		</td>	
		<?php
		$i++;
		if($i%3==0)
		{
		?>
		</tr>
		<?php
		}
		}
		?>
		</table>

<?php
}
else if($p==0 and $_REQUEST[cat_id]!="" and $_REQUEST[prod_id]=="")
{
echo "<font class='head'>Sorry! There is no product of this Category...</font>";
}
?>

<!--------------------------------------------------------------------------------------->
<?php
if(($_REQUEST[prod_id]!="" && $_REQUEST[buy]=="" && $_REQUEST[buyer]==""
 && $_REQUEST[cart]=="")) 
{
$pro_details=mysql_query("select * from product where pro_id='$_REQUEST[prod_id]'");
$pro_det=mysql_fetch_assoc($pro_details);
?>
<table>
<tr height="50px"><td colspan="2" class="head"><?php echo $info;?></td></tr>
<tr>
<td width="200px" align="center" style="border:solid 1px #CCCCCC"><img src="<?php echo $pro_det[user_pro_img];?>" height="200px" width="170px" onclick="shoow()" style="cursor:pointer"/></td>

<td width="500px">
<!--------------->
<table cellspacing="0px" cellpadding="5px" border="0"><form name="qnt_frm" action="" method="post">
<tr height="30px"><td class="head" colspan="3"><?php echo $pro_det[pro_name];?></td></tr>
<tr><td style="border-bottom:double 4px #446499" class="sml_desc" colspan="3"><?php echo $pro_det[pro_desc];?></td></tr>
<tr height="5px"><td colspan="3"></td></tr>
<tr bgcolor="#E5E5E5"><td width="22%" class="mid">Quantity</td><td width="10%"><input type="text" name="qnt_txt" value="1" size="1" id="qnt" onblur="chk()" /></td><td class="black_txt" id="stk"><?php echo $pro_det[pro_minst];?>&nbsp;available</td></tr>
<tr bgcolor="#E5E5E5"><td class="mid">Price</td>	<td class="head">Rs.<?php echo $pro_det[pro_price];?></td><td><input type="image" src="images/seeit-button.png" name="buy_bnt"/></td></tr><input type="hidden" name="buy" value="<?php echo $pro_det[pro_id];?>"  /></form>
<form name="cart_frm" action="" method="post">
<input type="hidden" name="cart_qnt" value="1"/>
<input type="hidden" name="cart" value="<?php echo $pro_det[pro_id];?>" />
<tr bgcolor="#E5E5E5"><td style="border-top:solid 1px #FFFFFF" class="black_txt" colspan="2">Or combine multiple purchase</td><td style="border-top:solid 1px #FFFFFF"><input type="image" src="images/add_to_cart-300x89[1].png" name="cart_bnt" /></td></tr>
</form>
</table>

<table>
<tr><td class="sml_desc" valign="top">Shipping:</td><td class="sml_desc"><b>FREE</b> flat rate courier - Delivery anywhere in India | <a href="#">see all details</a></td></tr>
<tr><td class="sml_desc" valign="top">Payments:</td><td class="sml_desc"><img src="images/pp_escrow_text_130807_62x12.gif" />(Credit card, EMI, Debit card, Online Bank Transfer) | <a href="#">see all details</a></td></tr>
<tr><td class="sml_desc" valign="top">Returns:</td><td class="sml_desc">Return policy not specified by the seller.<br /> Check item description for more details about Return Policy.</td></tr>
</table>
<!--------------->
</td>
</tr>
<tr><td colspan="2" width="700px"><p onclick="tmc()" style="cursor:pointer" class="mid">Terms & conditions</p>
<div style="display:none; padding:5px; text-align:justify;" class="sml" id="terms">The Terms and Conditions contained herein along
 form an Agreement regulating our relationship with regard to the use of <b>�SouthCityMall.com�</b> by you.
Please read this Agreement carefully. You are advised to regularly check for any
amendments or updates to the terms and conditions from time to time. SouthCityMall.com 
may add to or change or update these Terms of Use, from time to time entirely at 
the its own discretion. You are responsible for checking these Terms of Use 
periodically to remain in compliance with these terms. Your use of a Site after 
any amendment to the Terms of Use shall constitute your acceptance of these terms
and you also agree to be bound by any such changes/revisions.
Any clause of terms and conditions if deemed invalid, void or for any reason 
unenforceable, shall be deemed severable and shall not affect the validity and
enforceability of the remaining clauses of the terms and conditions. Your Product
will be delivered into 5-7 working days, may be it take 2 or 3 extra days due
to any genuine reason.&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;<p onclick="clen()" style="cursor:pointer" class="mid">Close</p></td></tr>
</div>
</table>
<?php
}
?>

<div align="center" style="z-index:+3; vertical-align:middle; position:absolute; left:300px; top:510px; display:none; cursor:pointer; border:double 3px #999999; padding:15px; background:#FFFFFF" id="fl_img">
<img src="<?php echo $pro_det[user_pro_img];?>" onmouseout="hidee()" />
</div>
<!------------------------------------------------------------------------------------>
<?php
if($_SESSION[user_main] && $_REQUEST[buy] && $_REQUEST[cart]=="")
{
$by=mysql_query("select * from product where pro_id='$_REQUEST[buy]'");
$buy=mysql_fetch_assoc($by);
?>
<script src="js/validation.js"></script>
<form name="purchase_frm" action="" method="post" onsubmit="return check(this)">
<table cellspacing="0px" cellpadding="10px" border="0" width="100%">
<tr height="30px"><td class="head" colspan="3" style="border-bottom:double 4px #446499">Product Name:&nbsp;<?php echo $buy[pro_name];?></td></tr>
<tr><td class="mid" width="20%">Your Name:</td><td><input type="text" name="buyer" onKeyPress="valid='abcdefghijklmnopqrstuvwxyz '; return limitchar(event)"  /></td></tr>
<tr><td class="mid">Account No:</td><td><input type="text" name="acc_no" onKeyPress="valid='0123456789'; return limitchar(event)" /></td></tr>
<input type="hidden" name="product_info" value="<?php echo $buy[pro_id];?>" />
<input type="hidden" name="tot_qnt" value="<?php echo $_REQUEST[qnt_txt];?>" />
<tr><td class="mid">Payment mode:</td>
<td><select name="mode">
	<option>Credit Card</option>
	<option>Paypal</option>
	<option>Account</option>
	</select></td>
</tr>

<tr><td class="mid">Bank Name:</td>
<td><select name="bank">
	<option>Bank of Baroda</option>
	<option>State Bank of India</option>
	<option>Allahabad Bank</option>
	<option>Axis Bank</option>
	<option>HDFC Bank</option>
	</select></td>
</tr>
<tr><td class="mid" valign="top">Bank Details:</td><td><textarea name="det"></textarea></td></tr>
<tr><td align="center" colspan="3"><input type="image" src="images/next.png" name="next_bnt" value="123"/></td></tr>
</table>
</form>
<?php 
}?>
<!----------------------------------------------------------------------------------->

<?php if($_REQUEST[buyer]!="")
{
$lst=mysql_query("select * from users where user_fname='$_SESSION[user_main]'");
$data=mysql_fetch_assoc($lst);
$bp=mysql_query("select * from product where pro_id='$_REQUEST[product_info]'");
$buy_pro=mysql_fetch_assoc($bp);
$d = date("d".'/'."m".'/'."Y");
$dd=date("d");
$mm=date("m");
$yy=date("Y");
?>
			<table cellspacing="0px" cellpadding="5px" border="0" width="100%">
			<form action="" method="get" onsubmit="return check(this)" name="bill_frm">
			<input type="hidden" name="bnme" />
			<input type="hidden" name="buid" value="<?php echo $data[user_id];?>" />
			<input type="hidden" name="bpid" value="<?php echo $buy_pro[pro_id];?>" />
			<input type="hidden" name="bqnt" />
			<input type="hidden" name="bacc" />
			<input type="hidden" name="bbank" />
			<input type="hidden" name="bpmode" />
			<input type="hidden" name="bdate" value="<?php $tme=mktime(0,0,0,$dd,$mm,$yy); echo $tme; ?>" />
			<input type="hidden" name="bvat" />
			<input type="hidden" name="bamt" />
			<tr><td class="head" style="border-bottom:double 4px #446499" colspan="2">Confirmation</td></tr>
			
			<tr height="35px"><td class="mid" style="border-bottom:solid 1px #446499" colspan="2"><b>Personal Details</b></td></tr>
			<tr><td class="mid" width="22%">Name:</td><td class="sml_desc" id="n"><?php echo $_REQUEST[buyer];?></td></tr>
			<tr><td class="mid">Address:</td><td class="sml_desc" id="2"><?php echo $data[user_add];?></td></tr>
			<tr><td class="mid">City:</td><td class="sml_desc" id="3"><?php echo $data[user_city];?></td></tr>
			<tr><td class="mid">E-mail:</td><td class="sml_desc" id="4"><?php echo $data[user_email];?></td></tr>
			<tr><td class="mid" valign="top">Mobile No:</td><td class="sml_desc" id="6"><?php echo $data[user_mob];?></td></tr>
			
			<tr height="35px"><td class="mid" style="border-bottom:solid 1px #446499" colspan="2"><b>Product Details</b></td></tr>
			<tr><td class="mid">Product Name:</td><td class="sml_desc" id="5"><?php echo $buy_pro[pro_name];?></td></tr>
			<tr><td class="mid">Product Details:</td><td class="sml_desc" id="6"><?php echo $buy_pro[pro_desc];?></td></tr>
			<tr><td class="mid">Product Price:</td><td class="sml_desc" id="7"><?php echo $buy_pro[pro_price];?></td></tr>
			<tr><td class="mid">Quantity:</td><td class="sml_desc" id="8"><?php echo $_REQUEST[tot_qnt];?></td></tr>
			
			<tr height="35px"><td class="mid" style="border-bottom:solid 1px #446499" colspan="2"><b>Bank Details</b></td></tr>
			<tr><td class="mid">Account No:</td><td class="sml_desc" id="9"><?php echo $_REQUEST[acc_no];?></td></tr>
			<tr><td class="mid">Bank:</td><td class="sml_desc" id="10"><?php echo $_REQUEST[bank];?></td></tr>
			<tr><td class="mid">Payment Mode:</td><td class="sml_desc" id="11"><?php echo $_REQUEST[mode];?></td></tr>			
			<tr><td class="mid">Date:</td><td class="sml_desc" id="12"><?php echo $d;?></td></tr>
			
			<tr><td class="mid" style="border-top:solid 1px #446499" colspan="2">&nbsp;</td></tr>
			<tr><td class="mid">VAT:</td><td class="mid" id="13"><?php $q=$_REQUEST[tot_qnt]; $pr=$buy_pro[pro_price]; echo ($q*$pr)*4/100;?></td></tr>
			<tr><td class="mid" style="border-bottom:solid 1px #446499">Total Amount:</td><td class="mid" style="border-bottom:solid 1px #446499"><b id="14"><?php echo ($q*$pr)+(($q*$pr)*4/100);?></b></td></tr>
			<tr><td>&nbsp;</td><td><input type="image" src="images/ok_bnt.png" name="ok_bnt" value="123" onclick="buy_submt();"/></td></tr>
			</form>
		</table>
<?php
}?>
<!----------------------------------------------------------------------------------->
<?php
if(($_REQUEST[cart] || $_REQUEST[buy] || $_REQUEST[login])&& $_SESSION[user_main]=="")
{
?>
<table cellspacing="0px" cellpadding="7px" border="0" width="100%">
<tr><td class="head" style="border-bottom:double 4px #446499" colspan="2">Welcome to SouthCityMall - Sign In</td></tr>
<form action="page/query.php" method="post" name="log_frm">
<tr height="45px"><td class="mid" style="border-bottom:solid 1px #446499" colspan="2"><b>Sign In to your Account...</b><font color="#BC3716" style="padding-left:250px" face="Comic Sans MS"><?php echo $_REQUEST[msg];?></font></td></tr>
<tr><td class="mid" width="20%">Username</td><td><input type="text" name="usr_name" onKeyPress="valid='abcdefghijklmnopqrstuvwxyz '; return limitchar(event)" /></td></tr>
<tr><td class="mid">Password</td><td><input type="password" name="usr_pass" /></td></tr>
<tr><td>&nbsp;</td><td class="black_txt"><input type="checkbox" name="keep" checked="checked" />Keep me logged In</td></tr>
<tr><td style="border-bottom:solid 1px #CCCCCC">&nbsp;</td><td style="border-bottom:solid 1px #CCCCCC"><a href="#" onclick="submt()"><img src="images/login_button.bmp" border="none" name="logimg"/></a></td></tr>
<tr><td>&nbsp;</td><td class="sml_desc">Are you guest ? please Register</td></tr>
<tr height="60px"><td>&nbsp;</td><td><a href="index.php?register=register" onmouseover="bnt()" onmouseout="bnt_chg()"><img src="images/regis.bmp" border="none" id="bbnt" /></a></td></tr>
</form>
</table>
<?php
}
?>
<!----------------------------------------------------------------------------------->
<?php
if($_REQUEST[lft_dept])
{
$lf=mysql_query("select * from category where cat_dept='$_REQUEST[lft_dept]'");
while($lft_ct=mysql_fetch_assoc($lf))
{
$lfte=mysql_query("select * from product where pro_cat='$lft_ct[cat_id]' and pro_minst>0");
$pn=mysql_num_rows($lfte);
?>
		
		<table border="0" cellpadding="5px" width="100%">
		<tr><td class="head" style="border-bottom:double 4px #446499" colspan="4"><?php if($pn>0) echo $lft_ct[cat_name];?></td></tr>
		<tr>
		<?php
		global $i;
		$i=0;	
		$lfpro=mysql_query("select * from product where pro_cat='$lft_ct[cat_id]' and pro_minst>0");
		while($lf_prod=mysql_fetch_assoc($lfpro))
		{
		?>
		<td>
		<table style="border:solid 1px #CCCCCC; padding:3px" width="200px" border="0">
		<tr><td rowspan="2" width="75px"><img src="<?php echo $lf_prod[user_pro_img];?>" height="100px" width="75px"/> </td>	<td style="border-bottom:solid 1px #446499" valign="bottom" class="normal" width="85px"><a href="index.php?prod_id=<?php echo $lf_prod[pro_id];?>&cat_id=<?php echo $_REQUEST[cat_id];?>"><?php echo $lf_prod[pro_name];?></a></td></tr>
		<tr><td valign="top" class="sml"><?php echo $lf_prod[pro_desc];?></td></tr>
		</table>
		</td>
		<?php
		$i++;
		if($i%3==0)
		{
		?>
		</tr>
		<?php
		}
		}
		?>
		</table>

<?php
}
}
?>
<!----------------------------------------------------------------------------------->
<?php
if($_REQUEST[register])
{
?>
<script src="js/validation.js"></script>
<table cellspacing="0px" cellpadding="5px" border="0" width="100%">
<form action="page/query.php" method="get" onsubmit="return check(this)" name="regis_frm">
<tr><td class="head" style="border-bottom:double 4px #446499" colspan="2">Registration</td></tr>
<tr><td class="mid" width="22%">First Name:</td><td><input type="text" name="fst_name" onKeyPress="valid='abcdefghijklmnopqrstuvwxyz '; return limitchar(event)" /></td></tr>
<tr><td class="mid">Last Name:</td><td><input type="text" name="lst_name" onKeyPress="valid='abcdefghijklmnopqrstuvwxyz '; return limitchar(event)"  /></td></tr>
<tr><td class="mid">Password:</td><td><input type="password" name="pass" maxlength="16" /></td></tr>
<tr><td class="mid">Re-Enter Password:</td><td><input type="password" name="re_pass" maxlength="16" /></td></tr>
<tr><td class="mid" valign="top">Address:</td><td><textarea name="addr"></textarea></td></tr>
<tr><td class="mid">E-mail:</td><td><input type="text" name="email" onblur="checkEmail(this)" /></td></tr>
<tr><td class="mid">City:</td><td><input type="text" name="city" onKeyPress="valid='abcdefghijklmnopqrstuvwxyz '; return limitchar(event)"  /></td></tr>
<tr><td class="mid">Mobile No:</td><td><input type="text" name="mob" onKeyPress="valid='0123456789'; return limitchar(event)" maxlength="11" /></td></tr>
<tr height="50px"><td>&nbsp;</td><td><input type="image" src="images/submit.bmp" name="sub_bnt" value="123"/></td></tr>
</form>
</table>
<?php
}
?>
<!----------------------------------------------------------------------------------->
<?php
if($_REQUEST[wel])
{
?>
<table cellspacing="0px" cellpadding="7px" border="0" width="100%">
<tr><td class="head" style="border-bottom:double 4px #446499" colspan="2"><?php echo $_REQUEST[usr];?>,&nbsp;Welcome to SouthCityMall</td></tr>
<tr height="45px"><td class="mid" style="border-bottom:solid 1px #446499" colspan="2"><b>Thankyou for joining us !!!</b></td></tr>
<tr><td colspan="2" class="mid">Now You are the member of <b>SouthCityMall</b>. Now you are able to purchase any item from this site. This site provides you all the information related to newly added product or about those products that newly came into market.</td></tr>
</table>
<?php
}
?>
<!----------------------------------------------------------------------------------->
<?php
if($_REQUEST[res])
{
?>
<table cellspacing="0px" cellpadding="7px" border="0" width="100%">
<tr><td class="head" style="border-bottom:double 4px #446499" colspan="2"><?php echo $_SESSION[user_main];?>,&nbsp;Congratulation</td></tr>
<tr height="45px"><td class="mid" style="border-bottom:solid 1px #446499" colspan="2"><b>Thank's for Purchasing !!!</b></td></tr>
<tr><td colspan="2" class="mid">Your Order has been made Your product should be delivered into <b>5-7</b> working days</td></tr>
</table>
<?php
}
?>
<!----------------------------------------------------------------------------------->
<?php 
if($_REQUEST[cat_id]=="" && $_REQUEST[prod_id]=="" && $_REQUEST[buy]=="" && $_REQUEST[wel]=="" && $_REQUEST[cart]=="" && $_REQUEST[register]=="" && $_REQUEST[login]=="" && $_REQUEST[lft_dept]=="" && $_REQUEST[buyer]=="" && $_REQUEST[view]=="" && $_REQUEST[ok_bnt]=="" && $_REQUEST[res]=="" && $_REQUEST[take]=="")
{
$strt=mysql_query("select * from product where pro_minst>0 order by rand() limit 0,9");
?>		
		<table border="0" cellpadding="5px" width="100%">
		<tr><td class="head" style="border-bottom:double 4px #446499" colspan="4">Today's Hot Deals</td></tr>
		<tr>
		<?php
		global $i;
		$i=0;	
		while($prod=mysql_fetch_assoc($strt))
		{
		?>
		<td>
		<table style="border:solid 1px #CCCCCC; padding:5px" width="200px" border="0">
		<tr><td rowspan="3" width="75px"><img src="<?php echo $prod[user_pro_img];?>" height="100px" width="85px" border="none"/></td>	<td style="border-bottom:solid 1px #446499" valign="bottom" class="normal" width="85px"><a href="index.php?prod_id=<?php echo $prod[pro_id];?>&cat_id=<?php echo $_REQUEST[cat_id];?>"><?php echo $prod[pro_name];?></a></td></tr>
		<tr><td valign="top" class="sml"><?php echo $prod[pro_desc];?></td></tr>
		<tr><td valign="top" class="norm">Rs.<?php echo $prod[pro_price];?></td></tr>
		</table>
		</td>	
		<?php
		$i++;
		if($i%3==0)
		{
		?>
		</tr>
		<?php
		}
		}
		?>
		</table>
	
<?php
}
?>
<!----------------------------------------------------------------------------------->
<?php if($_REQUEST[view])
{ 
$ur=mysql_query("select * from users where user_fname='$_SESSION[user_main]'");
$us=mysql_fetch_assoc($ur);
$ch=mysql_query("select * from cart,product where cart_usr_id='$us[user_id]' and pro_id=cart_pro_id");
?>
<table cellspacing="0px" cellpadding="7px" border="0" width="100%">
<tr><td class="head" style="border-bottom:double 4px #446499" colspan="6">Product Cart</td></tr>
<tr>
	<td class="mid" width="200px" style="border-bottom:double 2px #446499" align="center">Product Name</td>
	<td class="mid" style="border-bottom:double 2px #446499" align="center">Action</td>
	<td class="mid" style="border-bottom:double 2px #446499" align="center">Price</td>
	<td class="mid" style="border-bottom:double 2px #446499" align="center">Quantity</td>
	<td class="mid" style="border-bottom:double 2px #446499" align="center">VAT</td>
	<td class="mid" style="border-bottom:double 2px #446499" align="center">Total</td>
</tr>
<?php 
global $sum;
$sum=0;
$bgcol="#AEAFDD";
while($cp=mysql_fetch_assoc($ch))
{
if($bgcol=="#AEAFDD")
{ $bgcol='#E4E4F3'; }
else {
$bgcol='#AEAFDD';}
?>
<tr bgcolor="<?php echo $bgcol;?>"><td class="sml_desc"><?php echo $cp[pro_name];?></td>
<td align="center"><a href="#" class="sml_desc" onclick="rmv('<?php echo $cp[cart_id];?>')">Remove</a></td>
<td class="sml_desc" align="center"><?php echo $cp[pro_price];?></td>
<td class="sml_desc" align="center"><?php echo $cp[cart_pro_qnt];?></td>
<td class="sml_desc" align="center"><?php $p=$cp[pro_price]; $q=$cp[cart_pro_qnt]; echo ($p*$q)*4/100;?></td>
<td class="sml_desc" align="center"><?php $t=($p*$q)+(($p*$q)*4/100); echo $t;?></td>
</tr>
<?php
$sum=$sum+$t;}
?>
<tr><td class="mid" style="border-top:double 2px #446499;border-bottom:double 2px #446499">Grand Total</td>
<td align="center" style="border-top:double 2px #446499;border-bottom:double 2px #446499"><a href="#" class="sml_desc" onclick="rmv_all('all')">Remove All</a></td>
<td colspan="3" style="border-top:double 2px #446499;border-bottom:double 2px #446499">&nbsp;</td>
<td style="border-top:double 2px #446499;border-bottom:double 2px #446499" class="mid" align="center"><?php echo $sum;?></td>
</tr>

<tr><td colspan="5">&nbsp;</td><td align="center"><a href="index.php?cartok=ok"><img src="images/ok_bnt.png" border="none" /></a></td></tr>
</table>
<?php
}
?>
<form name="cart_frm_rem" action="" method="post">
<input type="hidden" name="rem" value="" />
</form>
<form name="cart_frm_remall" action="" method="post">
<input type="hidden" name="remall" value="" />
</form>
<!----------------------------------------------------------------------------------->
<script src="js/validation.js"></script>
<div style="display:none; position:absolute; left:375px; top:1000px; border:solid 2px #446499; background:#FFFFFF" id="dd">
<table cellspacing="0px" cellpadding="7px" border="0" width="100%">
<tr><td class="head" style="border-bottom:double 4px #446499" background="images/Untitled.png">Feedback</td>
<td class="hed" align="right" style="border-bottom:double 4px #446499" background="images/Untitled.png"><a style="cursor:pointer" onclick="hde()">x</a></td></tr>
<tr><td class="mid">Name<font color="#D41F00">*</font></td> <td class="mid">Email<font color="#D41F00">*</font></td></tr>
<form name="feed_frm" action="" method="post" onsubmit="return check(this)">
<tr><td><input type="text" name="fname" onKeyPress="valid='abcdefghijklmnopqrstuvwxyz '; return limitchar(event)" /></td> <td><input type="text" name="femail" onblur="checkEmail(this)" /></td></tr>
<tr><td colspan="2" class="mid">Description<font color="#D41F00">*</font></td></tr>
<tr><td colspan="2"><input type="text" name="fdesc" height="2" /></td></tr>
<tr><td align="right"><input type="image" src="images/feedsub.png" name="fsub_bnt" /></td><td align="left"><img src="images/feedcancel.png" style="cursor:pointer" onclick="hde()" /></td></tr>
</form>
</table>
</div>
<!------------------------------------------------------------------------------------>
<?php if($_REQUEST[take])
{
?>
<script src="js/validation.js"></script>
<table cellspacing="0px" cellpadding="7px" border="0" width="100%">
<form action="" method="post" name="cartok_frm" onsubmit="return check(this)">
<tr><td class="head" style="border-bottom:double 4px #446499" colspan="2">&nbsp;Please Enter...</td></tr>
<tr><td class="mid" width="20%">Your Name:</td><td><input type="text" name="buyer_cart" onKeyPress="valid='abcdefghijklmnopqrstuvwxyz '; return limitchar(event)"  /></td></tr>
<tr><td class="mid">Account No:</td><td><input type="text" name="acc_no_cart" onKeyPress="valid='0123456789'; return limitchar(event)" /></td></tr>

<tr><td class="mid">Payment mode:</td>
<td><select name="mode_cart">
	<option>Credit Card</option>
	<option>Paypal</option>
	<option>Account</option>
	</select></td>
</tr>

<tr><td class="mid">Bank Name:</td>
<td><select name="bank_cart">
	<option>Bank of Baroda</option>
	<option>State Bank of India</option>
	<option>Allahabad Bank</option>
	<option>Axis Bank</option>
	<option>HDFC Bank</option>
	</select></td>
</tr>
<tr><td class="mid" valign="top">Bank Details:</td><td><textarea name="det_cart"></textarea></td></tr>
<tr><td align="center" colspan="3"><input type="image" src="images/ok_bnt.png" name="final_bnt" value="123"/></td></tr>
</form>
</table>
<?php }
?>


