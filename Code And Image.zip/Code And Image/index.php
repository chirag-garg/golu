<?php
include('share.php');
if($_REQUEST[cart] && $_SESSION[user_main])
{
$ss=mysql_query("select * from users where user_fname='$_SESSION[user_main]'");
$s=mysql_fetch_assoc($ss);
$cart=mysql_query("select * from cart where cart_pro_id='$_REQUEST[cart]' and cart_usr_id='$s[user_id]'");
$cno=mysql_num_rows($cart);
$ct=mysql_fetch_assoc($cart);
$pmat=mysql_query("select * from product where pro_id=$ct[cart_pro_id]");
$pmt=mysql_fetch_assoc($pmat);
$r=($ct[cart_pro_qnt]+$_REQUEST[cart_qnt]);

	if($cno>0)
	{ if($r<=$pmt[pro_minst])
		{
	mysql_query("update cart set cart_pro_qnt=$r where cart_pro_id='$_REQUEST[cart]' and cart_usr_id='$s[user_id]'");
		header("location:index.php");
		}
		else
		{
		header("location:index.php?alt=alt");
		}
	}
	else
	{
	$d=mysql_query("insert into cart set 
				cart_pro_id='$_REQUEST[cart]',
				cart_usr_id='$s[user_id]',
				cart_pro_qnt='$_REQUEST[cart_qnt]'");
		$info="Your Product is Successfully Added into Cart !!!";
			header("location:index.php");	
	}
}
///////////////////////////////////////////////////////////
if($_REQUEST[alt]=="alt")
echo "<script>alert('That much Quantity is not available');</script>";
///////////////////////////////
if($_REQUEST[cartok])
{ $ur=mysql_query("select * from users where user_fname='$_SESSION[user_main]'");
$us=mysql_fetch_assoc($ur);
$ctr=mysql_query("select * from cart where cart_usr_id=$us[user_id]");
	while($cpro=mysql_fetch_assoc($ctr))
	{
	mysql_query("insert into product_order set ord_usr_id=$cpro[cart_usr_id],
											ord_pro_id=$cpro[cart_pro_id],
											ord_pro_qnt=$cpro[cart_pro_qnt]");
	}header("location:index.php?take=take");
}
//////////////////////////////////////////////////////////////////
if($_REQUEST[bnme])
{
$m=mysql_query("select * from product where pro_id='$_REQUEST[bpid]'");
	$md=mysql_fetch_assoc($m);
	$oldqnt=$md[pro_minst];
	$newqnt=$_REQUEST[bqnt];
	$res=($oldqnt-$newqnt);
	$upqnt=mysql_query("update product set pro_minst=$res where pro_id=$_REQUEST[bpid]");
$qre=mysql_query("insert into product_order set
 				ord_usr_name='$_REQUEST[bnme]',
				ord_usr_id='$_REQUEST[buid]',
				ord_pro_id='$_REQUEST[bpid]',
				ord_pro_qnt='$_REQUEST[bqnt]',
				ord_usr_acc='$_REQUEST[bacc]',
				ord_usr_bank='$_REQUEST[bbank]',
				ord_usr_mode='$_REQUEST[bpmode]',
				ord_date='$_REQUEST[bdate]',
				ord_vat='$_REQUEST[bvat]',
				ord_amt='$_REQUEST[bamt]'");
		header("location:index.php?res=$res");
}
//////////////////////////////////////////////////////////////////
if($_REQUEST[logout]=="logout")
{
$ur=mysql_query("select * from users where user_fname='$_SESSION[user_main]'");
$us=mysql_fetch_assoc($ur);
mysql_query("delete from cart where cart_usr_id=$us[user_id]");
$_SESSION[user_main]="";
}
///////////////////////////////////////////////////////////////////
if($_REQUEST[fname])
{
mysql_query("insert into testimonial set test_name='$_REQUEST[fname]',
											test_email='$_REQUEST[femail]',
											test_desc='$_REQUEST[fdesc]'");
			header("location:index.php");
}
////////////////////////////////////////////////////////////////////
		if($_REQUEST[rem])
		{ 
		mysql_query("delete from cart where cart_id='$_REQUEST[rem]'");
		header("location:index.php?view=view");
		}
////////////////////////////////////////////////////////////////////
		if($_REQUEST[remall])
		{
		$d=mysql_query("select * from users where user_fname='$_SESSION[user_main]'");
		$al=mysql_fetch_assoc($d);
		mysql_query("delete from cart where cart_usr_id=$al[user_id]");
		header("location:index.php");
		}
//////////////////////////////////////////////////////////////////////
if($_REQUEST[buyer_cart])
{$d=mysql_query("select * from users where user_fname='$_SESSION[user_main]'");
		$al=mysql_fetch_assoc($d);
mysql_query("update product_order set ord_usr_name='$_REQUEST[buyer_cart]',
									ord_usr_acc='$_REQUEST[acc_no_cart]',
									ord_usr_bank='$_REQUEST[bank_cart]',
									ord_usr_mode='$_REQUEST[mode_cart]'
			where ord_usr_id=$al[user_id]");
mysql_query("delete from cart where cart_usr_id=$al[user_id]");
			header("location:index.php?res=res");
}
?>
<script type="text/javascript" src="js/jquery-1.6.4.js"></script>
<script>
function rmv(val)
{
	if(confirm("Are you sure to delete"))
	{
		document.cart_frm_rem.rem.value=val;
		document.cart_frm_rem.submit();
	}
}
function rmv_all(des)
{
	if(confirm("Are you really want to clear the cart"))
	{
		document.cart_frm_remall.remall.value=des;
		document.cart_frm_remall.submit();
	}
}
</script>

<center>
<body background="images/bodyback.png" style="background-repeat:repeat-x">
<table border="0" width="950px" cellpadding="0px" cellspacing="0px" style="border:solid 1px #A5A6DA;" bgcolor="#FFFFFF">
<tr><td colspan="2" bgcolor="#FFFFFF"><?php include('header.php'); ?></td></tr>

<tr>
<td style="padding-left:30px"><font class="head"><?php echo $_SESSION[user_main];?>&nbsp;</font>&nbsp;
<font class="normal"><a href="index.php?view=view" class="nmltxt">
<?php $ur=mysql_query("select * from users where user_fname='$_SESSION[user_main]'");
$us=mysql_fetch_assoc($ur);
$ch=mysql_query("select * from cart where cart_usr_id='$us[user_id]'");
$n=mysql_num_rows($ch);
if($n>0){echo "View My Cart";}else{}?>
</a></font></td>

<td align="right" style="padding-right:20px" class="sml">
<?php if($_SESSION[user_main]=="")
 	{
  echo "I am already a user. I want to <font class='normal'><a href='index.php?login=log'>Login</a></font>"; }
  else { echo "<font class='normal'><a href='index.php?logout=logout'>Logout</a></font>";}
  ?>
  
</td>

</tr>

<tr><td colspan="2" bgcolor="#FFFFFF" align="center"><?php include('page/img_slide.php');?></td></tr>

<tr>
	<td valign="top" class="head" width="200px" bgcolor="#FFFFFF" style="padding-top:5px;padding-left:5px;"><u>Latest Products</u><?php include('page/left_pro.php');?></td>
	<td style="border-left:solid 2px #6B6DC2; padding:10px" width="700px" valign="top" bgcolor="#FFFFFF"><?php include('page/output_pro.php');?></td>
</tr>

<tr height="25px"><td colspan="5">&nbsp;</td></tr>
<tr height="200px"><td colspan="2"><?php include('page/bottom_info.php');?></td></tr>

<tr bgcolor="#FFFFFF"><td colspan="2"><?php include('footer.php'); ?></td></tr>
</table>
</body>
</center>