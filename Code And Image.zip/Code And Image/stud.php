<script type="text/javascript" src="js/jquery-1.6.4.js"></script>
<script>
function shw()
{
$("#1").slideToggle();
$("#2").hide({height:100},"slow");
$("#3").hide({height:100},"slow");
}
function shw1()
{
$("#2").slideToggle();
$("#1").hide({height:100},"slow");
$("#3").hide({height:100},"slow");
}
function shw2()
{
$("#3").slideToggle();
$("#2").hide({height:100},"slow");
$("#1").hide({height:100},"slow");
}

</script>
<div>
	<div style="float:left; width:100px" align="center"><a href="#" onClick="shw()">Faculties</a>
		<div style="display:none; z-index:+1" id="1" align="left">
		<li>UG Teachers</li>
		<li>PG Teachers</li>
		<li>Chancellor</li>
		<li>Dean</li>
		<li>Priciple</li>
		</div>
	</div>
	
	<div style="float:left; width:100px" align="center"><a href="#" onClick="shw1()">Student Zone</a>
		<div style="display:none" id="2" align="left">
		<li>Results</li>
		<li>Grade Card</li>
		<li>Term-End Results</li>
		</div>
	</div>
	
	<div style="float:left; width:100px" align="center"><a href="#" onClick="shw2()">AboutUs</a>
		<div style="display:none" id="3" align="left">
		<li>History</li>
		<li>Future Scope</li>
		</div>
	</div>
</div>